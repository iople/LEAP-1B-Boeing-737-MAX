# 规格 · 场景 / 材质 / 交互 / 主循环

---

## 一、场景与渲染器

```js
const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.setSize(innerWidth, innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.02;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.localClippingEnabled = true;      // 剖视必需
```

## 二、相机与控制

```js
const camera = new THREE.PerspectiveCamera(34, innerWidth / innerHeight, 0.6, 400);
camera.position.copy(HOME_POS);

const controls = new OrbitControls(camera, renderer.domElement);
controls.target.copy(HOME_TGT);
controls.enableDamping = true;
controls.dampingFactor = 0.075;
controls.minDistance = 7;
/* 分解后整体包围球半径约 15.4，窄窗口下需要 ~130 才装得下，
   上限 96 会截断导致部件被切出画面。放到 170 留足余量。 */
controls.maxDistance = 170;
controls.maxPolarAngle = Math.PI * 0.87;
controls.autoRotateSpeed = 0.75;
controls.update();
```

```js
const HOME_POS = new THREE.Vector3(16.6, 8.4, 21.0);
const HOME_TGT = new THREE.Vector3(-0.45, 0.30, -0.55);
```

> `far` 必须配合 `maxDistance`：`far = 400` 才容得下 170 的距离外加模型纵深。

## 三、光照与环境

```js
const pmrem = new THREE.PMREMGenerator(renderer);
pmrem.compileEquirectangularShader();
const envRT = pmrem.fromScene(new RoomEnvironment(), 0.028);
scene.environment = envRT.texture;

const hemi = new THREE.HemisphereLight(0xffffff, 0xD5DEEA, 0.68);

const key = new THREE.DirectionalLight(0xffffff, 2.30);
key.position.set(7.5, 11.0, 8.5);
key.castShadow = true;
key.shadow.mapSize.set(2048, 2048);
key.shadow.camera.near = 1;
key.shadow.camera.far = 48;
key.shadow.camera.left = -11;  key.shadow.camera.right = 11;
key.shadow.camera.top = 11;    key.shadow.camera.bottom = -11;
key.shadow.bias = -0.0006;
key.shadow.normalBias = 0.022;

const fill = new THREE.DirectionalLight(0xCFE0FF, 0.88);
fill.position.set(-9.5, -3.5, -7.0);

const rim = new THREE.DirectionalLight(0xFFFFFF, 1.20);
rim.position.set(-4.0, 5.5, -11.0);
```

## 四、地面

```js
const floorY = -4.72;
const grid = new THREE.GridHelper(52, 52, 0xC2CCDA, 0xD9E1EA);
grid.position.y = floorY;
grid.material.transparent = true;
grid.material.opacity = 0.5;

const shadowPlane = new THREE.Mesh(
  new THREE.PlaneGeometry(52, 52),
  new THREE.ShadowMaterial({ color: 0x22324A, opacity: 0.16 })
);
shadowPlane.rotation.x = -Math.PI / 2;
shadowPlane.position.y = floorY + 0.005;
shadowPlane.receiveShadow = true;
```

## 五、材质色值表 `C`

```js
const C = {
  paint: 0xF3F6FA, paint2: 0xE3E9F0,
  carbon: 0x191D21, carbon2: 0x23282E,
  steel: 0xC6CDD6, steelMid: 0x8D97A4, steelDark: 0x4E5866,
  ti: 0xB9C3CE, silver: 0xD9DFE6,
  cmc: 0xA4AC9E, hot: 0x9C7C5E, copper: 0xB0743D,
  red: 0xA32E1C, orange: 0xBE5520, rubber: 0x22262B, wire: 0x33383F
};
```

### 材质工厂

```js
const CLIP_MATS = [];
function track(m, clip) { if (clip) CLIP_MATS.push(m); return m; }
function matPaint(clip) {
  return track(new THREE.MeshPhysicalMaterial({
    color: C.paint, roughness: 0.42, metalness: 0.05,
    clearcoat: 0.42, clearcoatRoughness: 0.34, side: THREE.DoubleSide
  }), clip);
}
function matPaint2(clip) {
  return track(new THREE.MeshPhysicalMaterial({
    color: C.paint2, roughness: 0.52, metalness: 0.12,
    clearcoat: 0.16, side: THREE.DoubleSide
  }), clip);
}
function matSteel(color = C.steel, metal = 0.92, rough = 0.3, clip = false) {
  return track(new THREE.MeshStandardMaterial({
    color, metalness: metal, roughness: rough, side: THREE.DoubleSide
  }), clip);
}
function matStd(color, metal, rough, opts = {}) {
  return new THREE.MeshStandardMaterial(Object.assign({
    color, metalness: metal, roughness: rough, side: THREE.DoubleSide
  }, opts));
}
```

> `matStd` **不登记** `CLIP_MATS`（声衬、整流锥、软管这类不需要裁剪）。`side: DoubleSide` 全篇统一，因为壳体是单层放样，背面也要可见。

## 六、四种程序化贴图

```js
const TEX = {
  carbon: carbonTexture(),
  brushed: brushedTexture('#C8CFD7'),
  brushedDark: brushedTexture('#A9B2BC')
};
```

### `carbonTexture()` —— 碳纤维编织
512×512，cell=36，底色 `#14171B`；每 2×2 组按 `((i>>1)+j) % 4 < 2` 决定斜纹方向（±45°），每格叠一层线性渐变（亮 `rgba(158,168,180,.16)` / 暗 `rgba(46,52,60,.05)`），再画 `rgba(6,8,10,.62)` 宽 2.2 的对角线。`repeat.set(7, 2.4)`，`anisotropy 8`。

### `brushedTexture(base)` —— 拉丝金属
512×128，填底色后画 **620 条**随机横线：透明度 0~0.10、线宽 0.3~1.9、`y` 抖动 ±1.2，颜色随机在 `rgba(255,255,255,a)` 与 `rgba(30,38,48,a)` 之间。`repeat.set(3, 1)`。

### `perfTexture()` —— 声衬穿孔
256×256，底 `#AFB6BF`，**16×16** 个半径 3.4 的孔，孔色 `#4E5763`。`repeat.set(10, 3)`，`anisotropy 4`。

### `spiralTexture()` —— 整流锥白螺旋
512×512，底 `#2A2E34`，`lineWidth 17`，`strokeStyle #EFF3F7`；用 `k = -1..2` 画 4 条 45° 长线（`(-20, b+20) → (532, b+512)`）保证接缝连续。`repeat.set(2, 1)`。

全部 `wrapS = wrapT = RepeatWrapping`、`colorSpace = SRGBColorSpace`。

## 七、交互状态

```js
const state = {
  filter: 'all', sel: null, hover: null,
  exploded: false, labels: false, spin: false, cut: false,
  bare: true, pipes: true
};
let explodeT = 0, explodeGoal = 0;
```

### 剖视

```js
const CLIP = new THREE.Plane(new THREE.Vector3(1, 0, 0), 0.02);
function applyCut(on) {
  state.cut = on;
  CLIP_MATS.forEach(m => {
    m.clippingPlanes = on ? [CLIP] : null;
    m.clipShadows = on;
    m.needsUpdate = true;
  });
  syncTools();
}
```

主循环里每帧更新法线方向（**这一段是纠错重点**）：

```js
// 剖切面：切掉靠近相机的那半边，才能看见内部。
// three 的裁剪规则是「法线·点 + constant < 0 的部分被移除」，
// 要切掉 x > c 就得把法线指向 -X。取 +X 会变成切远侧，近侧外壳照样挡着。
if (state.cut) {
  const sgn = camera.position.x >= controls.target.x ? -1 : 1;
  CLIP.normal.set(sgn, 0, 0);
  CLIP.constant = 0.02;
}
```

### 裸机 / 短舱双模

```js
/* 裸机模式下隐藏的部件：短舱 / 进气道 / 吊挂这类"装机外壳"。
   风扇机匣 06、箍带 07、导流叶片 08 都保留——它们是裸机状态的主角，
   半径已收到短舱内壁以内，装机时不会再戳出来。 */
const NAC_HIDDEN = ['01', '02', '09', '10', '11', '25'];
function setMode(bare) {
  state.bare = bare;
  NAC_HIDDEN.forEach(id => { if (P[id]) P[id].group.visible = !bare; });
  if (P['26']) P['26'].group.visible = bare;
  Object.keys(rowEls).forEach(id => {
    rowEls[id].classList.toggle('off', bare && NAC_HIDDEN.indexOf(id) >= 0);
  });
  const visibleCount = bare ? PARTS.length - NAC_HIDDEN.length : PARTS.length;
  $('cntN').textContent = state.filter === 'all'
    ? visibleCount
    : PARTS.filter(p => p.cat === state.filter && !(bare && NAC_HIDDEN.indexOf(p.id) >= 0)).length;
  dimTargets();
  updateLabels();
  syncTools();
}
```

> **常量名只用 `NAC_HIDDEN`，没有 `NAC_PARTS`。** 曾误在 `setFilter()` 里引用 `NAC_PARTS`，导致点分类 chip 抛 `ReferenceError`，而首屏完全正常、截图看不出来。

### 淡出与高亮

```js
function dimTargets() {
  Object.keys(P).forEach(id => {
    const p = P[id];
    const inFilter = state.filter === 'all' || MAP[id].cat === state.filter;
    let f = inFilter ? 1 : 0.30;
    if (state.sel) f *= (state.sel === id) ? 1 : 0.26;
    if (state.hover && state.hover !== id && state.hover !== state.sel) f *= 0.9;
    p.mats.forEach(m => {
      const b = m.userData.base;
      if (f < 0.99) {
        m.transparent = true; m.opacity = Math.max(0.06, b.opacity * f); m.depthWrite = false;
      } else {
        m.transparent = b.transparent; m.opacity = b.opacity; m.depthWrite = b.depthWrite;
      }
    });
    p.mats.forEach(m => {
      if (!m.emissive) return;
      if (state.hover === id) { m.emissive.setHex(0x1E6FD9); m.emissiveIntensity = 0.30; }
      else if (state.sel === id) { m.emissive.setHex(0xF26A1E); m.emissiveIntensity = 0.22; }
      else { m.emissive.copy(m.userData.base.emissive); m.emissiveIntensity = m.userData.base.emissiveIntensity; }
    });
  });
}
```
hover = 蓝 `0x1E6FD9` @0.30，select = 橙 `0xF26A1E` @0.22。淡出时**必须同时关 `depthWrite`**，否则半透明件会互相遮挡出脏边。

## 八、工具条

八项，`ICONS` 是 24×24 描边 SVG 路径（`stroke-width 1.7`）：

| id | 标签 | 行为 |
|---|---|---|
| `explode` | 分解 | 切换 `state.exploded` / `explodeGoal`；开时调 `explodeView()`，关时 `resetView()` |
| `collapse` | 合拢 | `exploded=false`，`explodeGoal=0` |
| `reset` | 重置视角 | `resetView()` |
| `labels` | 标注 | 切换 `state.labels` + `updateLabels()` |
| `spin` | 旋转 | 切换 `controls.autoRotate` |
| `cut` | 剖视 | `applyCut(!state.cut)` |
| `mode` | 短舱 / 裸机 | `setMode(!state.bare)`，`sep:true` 与前面隔开。**按钮文字随状态变**：裸机时显示"短舱"，短舱时显示"裸机" |
| `pipes` | 管线 | 切换 `P['23'].group.visible` 与 `P['24'].group.visible` |

```js
function syncTools() {
  [...tbEl.children].forEach(b => {
    const id = b.dataset.tool;
    let on = (id === 'explode' && state.exploded) || (id === 'labels' && state.labels) ||
             (id === 'spin' && state.spin) || (id === 'cut' && state.cut) ||
             (id === 'mode' && !state.bare) || (id === 'pipes' && state.pipes);
    b.classList.toggle('on', on);
    if (id === 'mode') b.querySelector('.lbl').textContent = state.bare ? '短舱' : '裸机';
  });
}
```

## 九、★ 分解视图自动取景（最容易翻车的一段）

**问题**：分解后整体包围球半径约 15.4。若按整窗 FOV 算距离，部件会飘到左侧部件栏（215 px）和右侧说明栏（330 px）底下——**在画布上可见，但被人眼看成"出画"**。

**错误做法**（都试过，都不行）：
1. 改 `camera.aspect` 为可用区宽高比 —— **不等效**。aspect 改的是水平 FOV 的推导基准，不是把画面往一边挪。
2. 迭代式求解 `d` —— **发散**。因为 `ox = dxPx·k·d` 与 `d` 成正比，`d` 越大偏移越大，正反馈。

**正确做法**：FOV 按**像素比例**缩到可用区 + 包围盒 8 角在相机系投影 + **二分**求最小距离 + 注视点平移到可用区中心。

```js
function explodeView() {
  const box = new THREE.Box3();
  const tmp = new THREE.Box3();
  Object.keys(P).forEach(id => {
    const p = P[id];
    if (!p.group.visible) return;
    tmp.setFromObject(p.group);
    tmp.translate(p.ex);            // 加上分解位移后的真实位置
    box.union(tmp);
  });
  if (box.isEmpty()) box.setFromObject(E);

  /* 取景要按"实际能看见的那块矩形"算，不能按整窗算：
     左侧部件栏 215 px、右侧说明栏 330 px、顶部标题 108 px、底部工具条 120 px
     都是盖在画布上的不透明面板，部件飘到这些区域下面就等于出画了。 */
  const W = innerWidth || 1600;
  const H = innerHeight || 900;
  const wide = W > 1180;                 // 面板在 1180 px 以下会隐藏
  /* 左栏实测占 215 px（面板本体），再留 40 px 安全边距——分解后左下角的
     部件最容易贴到面板边上，之前只留 6 px，窗口差一点就被压住。 */
  const occlL = wide ? 255 : 0;
  const occlR = wide ? 350 : 0;
  const occlT = 108, occlB = 120;
  const usableW = Math.max(240, W - occlL - occlR);
  const usableH = Math.max(240, H - occlT - occlB);

  const vFov = camera.fov * D2R;
  const hFovReal = 2 * Math.atan(Math.tan(vFov / 2) * (W / H));
  /* 可用区对应的有效视角（线性按像素比缩放） */
  const vEff = vFov * (usableH / H);
  const hEff = hFovReal * (usableW / W);

  const az = 74 * D2R, el = 15 * D2R;
  const camDir = new THREE.Vector3(
    -Math.cos(el) * Math.sin(az), Math.sin(el), Math.cos(el) * Math.cos(az)
  );                                     // 由 target 指向相机的方向
  const right = new THREE.Vector3().crossVectors(camDir, new THREE.Vector3(0, 1, 0)).normalize();
  const up = new THREE.Vector3().crossVectors(right, camDir).normalize();

  /* 设角点在相机系下相对包围盒中心为 (px, py, pz)。
     把注视点放在【可用区中心】而不是包围盒中心：屏幕上的可用区相对窗口
     中心偏移 (dxPx, dyPx) 像素，注视点沿 right/up 走 ox/oy 之后，
     角点相对注视点的横向坐标就变成 (px - ox)，纵向 (py - oy)。
     约束：|px - ox| ≤ (d - pz)·th，|py - oy| ≤ (d - pz)·tv。
     ox = d·k·dxPx 与 d 成正比，代入后 d 出现在两边——形式容易写错，
     改用二分：d 越小越可能溢出，单调性成立，26 步足够。 */
  const center = box.getCenter(new THREE.Vector3());
  const vFov2 = Math.min(vEff, Math.PI * 0.98) / 2;
  const hFov2 = Math.min(hEff, Math.PI * 0.98) / 2;
  const tv = Math.tan(vFov2), th = Math.tan(hFov2);

  const cxUsable = (occlL + (W - occlR)) / 2;
  const dxPx = cxUsable - W / 2;
  const cyUsable = (occlT + (H - occlB)) / 2;
  const dyPx = cyUsable - H / 2;

  /* 每单位 d 对应的"每像素世界宽度/高度" */
  const kH = (2 * Math.tan(hFovReal / 2)) / W;
  const kV = (2 * Math.tan(vFov / 2)) / H;

  const corners = [];
  for (let i = 0; i < 8; i++) {
    const c = new THREE.Vector3(
      (i & 1) ? box.max.x : box.min.x,
      (i & 2) ? box.max.y : box.min.y,
      (i & 4) ? box.max.z : box.min.z
    ).sub(center);
    corners.push([c.dot(right), c.dot(up), c.dot(camDir)]);
  }

  /* 二分找满足条件的最小 d；fits 内部已按 PAD 收紧边界，
     所以最后不再额外乘系数（否则会多放大一次反而溢出）。 */
  const PAD = 0.92;                       // 可用矩形内缩 8% 作为呼吸边距
  const fits = (d) => {
    const ox = dxPx * kH * d;
    const oy = dyPx * kV * d;
    for (const [px, py, pz] of corners) {
      const depth = d - pz;
      if (depth <= 0.1) return false;
      if (Math.abs(px - ox) > depth * th * PAD) return false;
      if (Math.abs(py - oy) > depth * tv * PAD) return false;
    }
    return true;
  };

  let lo = 5, hi = controls.maxDistance;
  if (!fits(hi)) {
    /* 上限都装不下（窗口极窄）——直接用上限，至少不会把模型推到相机后面 */
    lo = hi;
  } else {
    for (let i = 0; i < 26; i++) {
      const mid = (lo + hi) / 2;
      if (fits(mid)) hi = mid; else lo = mid;
    }
  }
  const d = Math.max(5, Math.min(controls.maxDistance, hi));

  /* 注视点 = 包围盒中心 + 沿可用区中心的偏移（偏移量按最终 d 换算） */
  const ox = dxPx * kH * d;
  const oy = dyPx * kV * d;
  const newTgt = center.clone()
    .add(right.clone().multiplyScalar(ox))
    .add(up.clone().multiplyScalar(oy));
  const toP = newTgt.clone().add(camDir.clone().multiplyScalar(d));
  /* #instant：无头截图时跳过补间，直接落位（正常交互仍走 tween） */
  if (location.hash.toLowerCase().includes('instant')) {
    camera.position.copy(toP);
    controls.target.copy(newTgt);
    controls.update();
    camTween = null;
  } else {
    tweenCam(toP, newTgt);
  }
}
```

**验收判据**：1600×900 下分解态，非背景像素的 bbox 应落在 x∈[223, 1328]、y∈[108, 780]。用灰度 <150 阈值扫（**不能用 200**——地面阴影本来就横跨全宽，会把 bbox 撑满）。

### 相机补间

```js
let camTween = null;
function tweenCam(toP, toT) {
  camTween = { t: 0, fromP: camera.position.clone(), toP, fromT: controls.target.clone(), toT };
}
function resetView() {
  camTween = { t: 0, fromP: camera.position.clone(), toP: HOME_POS.clone(),
               fromT: controls.target.clone(), toT: HOME_TGT.clone() };
}
function tickCam(dt) {
  if (!camTween) return;
  camTween.t = Math.min(1, camTween.t + dt * 1.5);
  const k = easeIO(camTween.t);
  camera.position.lerpVectors(camTween.fromP, camTween.toP, k);
  controls.target.lerpVectors(camTween.fromT, camTween.toT, k);
  if (camTween.t >= 1) camTween = null;
}
```

## 十、拾取与标签

```js
const ray = new THREE.Raycaster();
const ptr = new THREE.Vector2();
let hoverDirty = false;
renderer.domElement.addEventListener('pointermove', ev => {
  const r = renderer.domElement.getBoundingClientRect();
  ptr.x = ((ev.clientX - r.left) / r.width) * 2 - 1;
  ptr.y = -((ev.clientY - r.top) / r.height) * 2 + 1;
  hoverDirty = true;
});
renderer.domElement.addEventListener('pointerdown', ev => { /* 同上换算 → pick() → select() */ });
function pick() {
  ray.setFromCamera(ptr, camera);
  const hits = ray.intersectObjects(E.children, true);
  for (const h of hits) {
    if (h.object.userData.pid && h.object.visible) return h.object.userData.pid;
  }
  return null;
}
```

hover 检测走脏标记，**不在 pointermove 里直接 raycast**（高频事件会卡）：

```js
if (hoverDirty) {
  hoverDirty = false;
  const id = pick();
  renderer.domElement.style.cursor = id ? 'pointer' : 'grab';
  if (id !== state.hover) { state.hover = id; dimTargets(); }
}
```

标签投影要**夹在可用区内**：

```js
function projectLabels() {
  if (!state.labels) return;
  const w = innerWidth, h = innerHeight;
  const lw = $('left').offsetWidth + 34;
  const rEl = $('right');
  const rw = rEl.offsetWidth ? rEl.offsetWidth + 34 : 34;
  const xmin = lw, xmax = w - rw, ymin = 92, ymax = h - 96;
  Object.keys(P).forEach(id => {
    const p = P[id];
    if (p.el.style.display === 'none') return;
    const v = p.anchor.clone().add(p.group.position).project(camera);
    if (v.z > 1) { p.el.style.opacity = '0'; return; }
    p.el.style.opacity = '1';
    const x = (v.x * 0.5 + 0.5) * w;
    const y = (-v.y * 0.5 + 0.5) * h;
    p.el.style.left = Math.max(xmin, Math.min(xmax, x)).toFixed(1) + 'px';
    p.el.style.top = Math.max(ymin, Math.min(ymax, y)).toFixed(1) + 'px';
  });
}
```

## 十一、主循环

```js
const clock = new THREE.Clock();
let lastAz = 0, lastEl = 0;

function loop() {
  requestAnimationFrame(loop);
  const dt = Math.min(0.05, clock.getDelta());
  tickCam(dt);

  if (hoverDirty) { /* 见上 */ }

  /* 分解位移：缓动插值，index 稳定遍历 */
  explodeT += (explodeGoal - explodeT) * Math.min(1, dt * 4.2);
  if (Math.abs(explodeGoal - explodeT) < 0.001) explodeT = explodeGoal;
  const ef = easeIO(clamp01(explodeT));
  Object.keys(P).forEach(id => {
    P[id].group.position.copy(P[id].ex).multiplyScalar(ef);
  });

  if (state.cut) { /* 见七、剖视 */ }

  controls.update();
  renderer.render(scene, camera);
  projectLabels();

  const az = controls.getAzimuthalAngle() * 180 / Math.PI;
  const el = 90 - Math.acos(clamp01((camera.position.y - controls.target.y) /
    Math.max(0.001, camera.position.distanceTo(controls.target)))) * 180 / Math.PI;
  if (Math.abs(az - lastAz) > 0.4 || Math.abs(el - lastEl) > 0.4) {
    lastAz = az; lastEl = el;
    $('az').textContent = (az < 0 ? az + 360 : az).toFixed(0) + '°';
    $('el').textContent = el.toFixed(0) + '°';
  }
}

addEventListener('resize', () => {
  camera.aspect = innerWidth / innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(innerWidth, innerHeight);
});
```

初始化顺序（**不能乱**）：

```js
overview();      // 先渲染右侧概览
setMode(true);   // 再定裸机态（内部会 dimTargets / updateLabels / syncTools）
syncTools();
dimTargets();
readHash();      // 最后读 hash 覆盖
loop();
```

## 十二、UI 结构（HTML + CSS 要点）

```
#bg      背景：radial-gradient 白→浅蓝 + 56px 网格叠加（mask 径向淡出）
#stage   three.js canvas
#labels  标签层（pointer-events:none）
#topbar  brand(左) + hero(中) + stats(右 4 个数据块)
#left    部件清单面板：宽 286px，top/bottom 92px，left 22px
#right   部件详情面板：宽 330px，right 22px
#toolbar 底部工具条，left 50% / bottom 22px
#foot / #hintL / #hintR  页脚与左右提示
```

配色变量：
```css
--paper:#EDF1F6; --ink:#0C1726; --ink2:#3A475C; --ink3:#7C879A;
--blue:#0B4FA8; --blue2:#08306B; --cyan:#0E93A8; --acc:#F26A1E;
--panel:rgba(255,255,255,.84);
```

面板统一 `backdrop-filter: blur(20px)` + `border-radius:16px` + 细边 `rgba(12,23,38,.10)`。

响应式断点（**与 `explodeView()` 的 `wide` 判据必须一致**）：
```css
@media (max-width:1180px){ #right{display:none} .stats .stat:nth-child(n+3){display:none} }
@media (max-width:880px){ #left{width:212px} .hero-1{font-size:17px} .hero-2{display:none}
                          .stats{display:none} .tb span.lbl{display:none} }
```
