# 验证 · 四件套

> **不做完四件套不算交付。** 每一条都对应过真实翻车。

---

## 一键运行

```bash
python scripts/verify.py <产物.html>
```

可选参数：`--width 1600 --height 900 --out <截图目录>`

输出示例（通过时）：
```
[1] 语法检查
[PASS] 语法检查通过 (node --check, 1777 行模块脚本)

[2] 真实渲染截图
[PASS] bare 截图 789063 字节 → bare.png
[PASS] cut 截图 767089 字节 → cut.png
[PASS] installed 截图 815272 字节 → installed.png
[PASS] exp 截图 719500 字节 → exp.png

[3] 控制台扫描
[PASS] 控制台无 Uncaught / ReferenceError / TypeError

[4] 分解取景量测
[PASS] 分解取景在可用区内 bbox=(416,220)-(1120,674) 可用=(255,108)-(1250,780)
```

依赖：`node`（语法）、Chrome 或 Edge（截图）、`Pillow`（量测，缺失时该项降级为 WARN 不阻断）。

---

## 第 1 件 · 语法检查

抽取 `<script type="module">` 到临时 `.mjs`，跑 `node --check`。

**为什么不能省**：整个文件是单个 module 脚本，任何一处 `Identifier already declared` 都会让**整段脚本不执行**——页面只剩 HTML 骨架，画布全白。而白屏从截图看跟"模型没渲染出来"一模一样，很难判断。

脚本还做 4 项静态可疑检查：

| 检查 | 命中含义 |
|---|---|
| 出现 `NAC_PARTS` / `NAC_HIDEN` | 未定义常量引用，点击筛选即抛错 |
| `fits` 定义两次 | 旧版本残留，新版本不生效 |
| 缺 `localClippingEnabled` | 剖视完全不生效 |
| 缺 `RoomEnvironment` | 金属材质在无环境贴图时发黑 |

---

## 第 2 件 · 真实渲染截图（四态）

```bash
chrome --headless=new --disable-gpu --allow-file-access-from-files \
  --hide-scrollbars --window-size=1600,900 --virtual-time-budget=7000 \
  --user-data-dir=<临时目录> \
  --screenshot=out.png "file:///<产物>#exp&instant"
```

四态固定为：

| 名称 | hash | 验收要点 |
|---|---|---|
| `bare` | 无 | 裸机：黑碳纤维机匣 + 4 道银箍带 + 顶部两根引气管 + 台架 |
| `cut` | `#cut` | 剖视：切**近相机侧**，能看见内部级 |
| `installed` | `#installed` | 完整短舱：外形连续，箍带不戳出罩体 |
| `exp` | `#exp&instant` | 分解：部件全部在可用区内 |

**两个必须注意的点**：

1. **`#instant` 不能省**。`--virtual-time-budget` 对 `requestAnimationFrame` 推进不可靠，相机补间约 67 帧才走完，不加只能截到第一帧——看到的是旧视角，会误判"改动没生效"。
2. **每张截图独立 `--user-data-dir`**。共用 profile 时第二个实例会连到第一个，等到超时。

判定：PNG < 20 KB 视为白屏（失败）。

### ★ 连续截图会偶发 0 字节，必须重试

快速连续启动 Chrome 时，`--screenshot` 有概率产出 0 字节文件或直接卡住，看起来像"产物白屏"。这和环境有关，不是产物缺陷。

`verify.py` 已内置处理：每张图独立 `--user-data-dir`、失败重试 2 次、每次间隔 2 秒。**不要因为一次 0 字节就判定产物报废**——先单独重测一张确认。

---

## 第 3 件 · 控制台扫描

```bash
chrome ... --enable-logging=stderr --dump-dom "file:///<产物>"
```

在 stderr 里找 `Uncaught` / `ReferenceError` / `TypeError`，**过滤掉 Chrome 自身的 `update_service_dialer` / `gpu_` / `dbus` / `Fontconfig` 噪声**（否则永远有假阳性）。

### ★ 离线版必须用「结构化判定」，不能简单 grep

离线版把 three.js 源码内联进页面，而**源码里本身就含 `TypeError` / `ReferenceError` 字样**（它自己的错误处理代码）。`--dump-dom` 会把整段脚本回显，简单 grep 立刻把源码判成"控制台异常"——纯假阳性，而且错过一次就会误以为产物坏了。

`scripts/verify.py` 里的 `_is_real_error()` 按结构判定：

| 规则 | 判定 |
|---|---|
| 含 `Uncaught` | 真错误 |
| `ERROR:CONSOLE(n)` + error/exception | 真错误 |
| 出现 `TypeError:` 等且**同时带** `file://` 或 `http` 栈信息 | 真错误 |
| 行长 > 600（DOM 回显的源码） | 忽略 |
| 以 `const` / `let` / `function` / `class` 开头 | 忽略 |
| 含 updater / gpu_ / dbus / fontconfig | 忽略 |

已用 8 条正负样本单测（真异常 3 条 + 源码回显/环境噪声 5 条），全数判对。

---

## 第 4 件 · 分解取景量测

**这一项最容易做错。**

目标：确认分解后模型的非背景像素 bbox 落在「可用区」内，没有被左右面板压住。

```python
# 灰度阈值必须 < 150
# 用 200 会把地面阴影（本来横跨全宽）算进实体，bbox 直接被撑满
```

可用区计算（**必须与 CSS 断点、`explodeView()` 三处一致**）：

```
wide = W > 1180
x ∈ [255, W-350]   （非 wide 时 [0, W]）
y ∈ [108, H-120]
```

实测基准（1600×900）：`bbox=(416,220)-(1120,674)`，可用区 `(255,108)-(1250,780)`。

### ★ 必须用 `#noui`

早期直接量普通截图，结果 bbox 是 `(22,16)-(1566,880)` —— **完全撑满整窗**。原因不是模型越界，而是**左侧面板的行列表文字、右侧详情卡文字本身就是深色**，全被算成"内容"。

所以成品内置 `#noui`：隐藏 `#topbar / #left / #right / #toolbar / #foot / #hint*`，只留画布。量测必须走：

```
#exp&instant&noui
```

> 这是本次打包过程中新加的能力。**没有它，这项检查永远失败且失败原因是假的。**

---

## 第 5 件（脚本查不了，必须人工点）

**交互级缺陷只看截图发现不了。** 打开产物，按这个顺序点一遍：

1. **六个分类 chip**：全部 / 进气系统 / 风扇系统 / 短舱与反推 / 核心机 / 附件与管路 —— 每个点一次，看左侧计数是否变化、有没有报错
2. **八项工具条**：分解 → 合拢 → 重置视角 → 标注 → 旋转 → 剖视 → 短舱/裸机 → 管线
3. **至少三个部件行**：点 06 风扇机匣、19 肋环、24 管路，看右侧详情卡内容是否对应
4. **点击模型本体**：验拾取是否命中正确部件（右侧标题应对上）
5. **窗口缩到 1000 px 宽**：右侧面板应消失，工具条只剩图标

真实案例：`setFilter()` 里引用了不存在的 `NAC_PARTS`，**首屏完全正常、四张截图全过**，但点任意分类 chip 立刻 `ReferenceError`，筛选全废。只靠截图会漏掉整类问题。

---

## 与基准图比对

`assets/reference/` 四张是 v2 的成品样张。复刻后逐张对照，重点看：

| 基准图 | 该看到的 |
|---|---|
| `v2-bare.png` | 黑色编织机匣、4 道银箍带（前窄后宽）、深色锥 + 白螺旋、顶部两根粗银管、核心机深色且管线密布、下方附件块与红盖油滤、台架 |
| `v2-cut.png` | 切近侧、可见压气机级片与燃烧室 |
| `v2-installed.png` | 白色短舱连续外形、箍带不戳出、吊挂在上、无台架 |
| `v2-exp.png` | 轴向分层清晰、部件全在可用区内 |

**允许的差异**：贴图随机噪声（`brushedTexture` 用 `Math.random()`，每次不同）、标签位置微差。
**不允许的差异**：颜色整体偏灰/偏亮、箍带数量不对、锥是白色、缺引气管、部件出画面。

---

## 常见失败对照

| 现象 | 去看 |
|---|---|
| 白屏 / 全空 | 语法检查失败；或 three.js CDN 没连上（沙箱断网） |
| 金属全黑 | 缺 `RoomEnvironment` |
| 剖视没反应 | 缺 `localClippingEnabled`，或法线符号反了 → P-01 |
| 剖视后残留黑点 | 材质没登记 `CLIP_MATS` → P-02 |
| 分解部件被面板压住 | `explodeView()` 用了整窗 FOV → P-10 |
| 分解模型被切边 | `maxDistance` 太小 → P-11 |
| 点分类报错 | 常量名写错 → `pitfalls.md` 末节 |
