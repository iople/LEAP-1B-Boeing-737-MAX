# 规格 · 几何（型线 + 工具函数 + 26 构建块）

> **数值照抄，不要"优化"。** 这些半径是从实拍视频里拟合出来的，改一个就可能让箍带从短舱里戳出来，或让导流叶片飞出机匣。

---

## 一、四条型线（轴向 z，半径 r；**+Z 为前端**）

### `NAC_OUT` 短舱外型线（19 点）

```js
const NAC_OUT = [
  [6.06, 3.80], [6.03, 3.90], [5.98, 4.00], [5.90, 4.09], [5.72, 4.20], [5.45, 4.26],
  [5.05, 4.29], [4.55, 4.29], [3.90, 4.27], [3.10, 4.25], [2.20, 4.22], [1.20, 4.18],
  [0.20, 4.13], [-0.80, 4.06], [-1.70, 3.98], [-2.50, 3.89], [-3.20, 3.78],
  [-3.80, 3.63], [-4.35, 3.46]
];
```

### `NAC_IN` 短舱内型线（18 点）

```js
const NAC_IN = [
  [6.06, 3.80], [6.02, 3.70], [5.95, 3.64], [5.80, 3.62], [5.55, 3.63], [5.10, 3.64],
  [4.50, 3.63], [3.80, 3.61], [3.00, 3.59], [2.10, 3.57], [1.20, 3.55], [0.30, 3.53],
  [-0.70, 3.51], [-1.60, 3.48], [-2.40, 3.45], [-3.10, 3.36], [-3.80, 3.20], [-4.35, 3.02]
];
```

### `CORE_OUT` 核心机罩外型线（14 点）

```js
const CORE_OUT = [
  [3.42, 2.20], [3.38, 2.28], [3.05, 2.39], [2.55, 2.42], [1.80, 2.39], [0.80, 2.34],
  [-0.20, 2.27], [-1.20, 2.18], [-2.20, 2.07], [-3.10, 1.96], [-3.90, 1.87],
  [-4.70, 1.80], [-5.30, 1.75], [-5.85, 1.70]
];
const CORE_IN = CORE_OUT.map(p => [p[0], p[1] - 0.15]);
```

### `FANCASE` 风扇机匣型线（7 点，裸机外露）

```js
/* 外径整体收 0.06，使外侧箍带（凸起 0.060）的顶点 3.624 仍小于
   短舱内壁 3.63——这样裸机能看到箍带，装机时又不会从罩体戳出来。 */
const FANCASE = [
  [5.44, 3.552], [5.20, 3.546], [4.85, 3.538], [4.40, 3.528],
  [3.95, 3.516], [3.62, 3.504], [3.34, 3.492]
];
const FANCASE_IN = FANCASE.map(p => [p[0], p[1] - 0.096]);
```

> **3.63 这个数是硬约束**：`FANCASE` 最外 3.552 + 箍带凸起 0.060 = 3.612 < `NAC_IN` 在 z≈4.5 处的 3.63。装机模式下箍带刚好藏在短舱内，裸机模式下露出来。调任何一个都要重新验算这条不等式。

---

## 二、工具函数（12 个，逐字照抄）

```js
function latheGeo(pts, seg = 110) {
  const v = pts.map(p => new THREE.Vector2(Math.max(0.001, p[1]), p[0]));
  const g = new THREE.LatheGeometry(v, seg);
  g.rotateX(Math.PI / 2);           // LatheGeometry 轴在 +Y，转到 +Z
  return g;
}
function shellGeo(outPts, inPts, seg = 120) {
  const loop = outPts.concat(inPts.slice().reverse());
  loop.push(outPts[0]);             // 闭合，形成有厚度的壳体
  return latheGeo(loop, seg);
}
function sampleR(pts, z) {
  if (z >= pts[0][0]) return pts[0][1];
  if (z <= pts[pts.length - 1][0]) return pts[pts.length - 1][1];
  for (let i = 0; i < pts.length - 1; i++) {
    const a = pts[i], b = pts[i + 1];
    if (z <= a[0] && z >= b[0]) {
      const t = (a[0] - z) / ((a[0] - b[0]) || 1);
      return a[1] + (b[1] - a[1]) * t;
    }
  }
  return pts[pts.length - 1][1];
}
function sliceP(pts, z0, z1) {
  const out = [[z0, sampleR(pts, z0)]];
  for (const p of pts) if (p[0] < z0 - 1e-6 && p[0] > z1 + 1e-6) out.push(p);
  out.push([z1, sampleR(pts, z1)]);
  return out;
}
function tubeShell(z0, z1, r0, r1, t, seg = 100) {
  return shellGeo([[z0, r0], [z1, r1]], [[z0, r0 - t], [z1, r1 - t]], seg);
}
function box(w, h, d, mat, x, y, z, rx, ry, rz) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
  m.position.set(x, y, z);
  if (rx) m.rotation.x = rx;
  if (ry) m.rotation.y = ry;
  if (rz) m.rotation.z = rz;
  return m;
}
```

### `surfStrip` —— 沿回转面铺连续窄带

用一整根定半径直条会在锥面两端悬空；用一串盒子拼接又会在锥面上错位露三角锯齿。正确做法是按型线放样：

```js
/* 沿回转面铺一条窄带（纵向加强条 / 安装边 / 长条贴片）。
   与"一段段盒子拼起来"相比：相邻段共用同一圈顶点、外法线连续，
   不会在锥面上错位露出三角锯齿。ang 为绕 Z 的角度，zA→zB 为轴向范围。 */
function surfStrip(prof, ang, zA, zB, halfAng, thick, mat, nZ = 40) {
  const pos = [], idx = [];
  for (let i = 0; i <= nZ; i++) {
    const z = zA + (zB - zA) * (i / nZ);
    const r = sampleR(prof, z);
    /* 同一 z 上取 4 个环向点：外表面两端 + 内表面两端
       （内表面压进壳体里 0.004 防漏光） */
    [[-halfAng, thick], [halfAng, thick], [halfAng, -0.004], [-halfAng, -0.004]]
      .forEach(([da, dr]) => {
        const a = ang + da;
        pos.push(Math.cos(a) * (r + dr), Math.sin(a) * (r + dr), z);
      });
  }
  for (let i = 0; i < nZ; i++) {
    const b = i * 4, c = (i + 1) * 4;
    for (let k = 0; k < 4; k++) {
      const k2 = (k + 1) % 4;
      idx.push(b + k, c + k, c + k2, b + k, c + k2, b + k2);
    }
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setIndex(idx);
  g.computeVertexNormals();
  return new THREE.Mesh(g, mat);
}
```

### `pathPipe` / `wrapPipe` —— 管路

```js
function pathPipe(pts, rad, mat, tub = 8, seg = 60) {
  const curve = new THREE.CatmullRomCurve3(pts.map(p => new THREE.Vector3(p[0], p[1], p[2])));
  return new THREE.Mesh(new THREE.TubeGeometry(curve, seg, rad, tub, false), mat);
}
/* 沿核心机表面绕行的管路：角度 a0→a1、轴向 z0→z1，半径取型线 + 间隙 */
function wrapPipe(o) {
  const pts = [];
  const n = o.n || 7;
  const a0 = o.a0 || 0;
  const a1 = (o.a1 === undefined) ? a0 : o.a1;
  for (let i = 0; i < n; i++) {
    const t = i / (n - 1);
    const z = lerp(o.z0, o.z1, t);
    let a = lerp(a0, a1, t);
    if (o.wave) a += Math.sin(t * Math.PI * (o.waveN || 1)) * o.wave;
    const r = lerp(o.r0, o.r1, t) + (o.off === undefined ? 0.07 : o.off);
    pts.push(new THREE.Vector3(Math.cos(a) * r, Math.sin(a) * r, z));
  }
  const curve = new THREE.CatmullRomCurve3(pts);
  return new THREE.Mesh(new THREE.TubeGeometry(curve, o.seg || 46, o.rad || 0.045, o.tub || 7, false), o.mat);
}
```

### `boltRing` —— 一圈径向朝外的六角头

```js
function boltRing(z, r, n, sz, mat) {
  /* 六角头沿径向朝外：CylinderGeometry 轴在 +Y，绕 Z 转 (a - π/2) 后
     轴变成径向 (cos a, sin a)。之前用 rotateX(π/2) 把轴转到 +Z，
     紧固件就成了朝前的一圈小柱，从侧面看是错位的黑点。 */
  const arr = [];
  for (let k = 0; k < n; k++) {
    const a = k * TAU / n;
    const g0 = new THREE.CylinderGeometry(sz, sz, sz * 1.05, 6);
    g0.translate(0, sz * 0.52, 0);
    g0.rotateZ(a - Math.PI / 2);
    g0.translate(Math.cos(a) * r, Math.sin(a) * r, z);
    arr.push(g0);
  }
  const merged = mergeGeometries(arr, false);
  arr.forEach(g => g.dispose());
  return new THREE.Mesh(merged, mat);
}
```

### `bladeGeo` —— 叶片放样（**径向 +Y，轴向 +Z，绕 Z 排布**）

这是整个项目最核心的一个函数。叶型是椭圆截面沿半径扫掠，每层按 `stag(s)` 扭转、按 `chord(s)` 变弦长、按 `thick(s)` 变厚度：

```js
function bladeGeo(o) {
  const n = o.n || 15, m = o.m || 20;
  const pos = [], idx = [], uv = [];
  for (let i = 0; i < n; i++) {
    const s = i / (n - 1);                       // 0=叶根, 1=叶尖
    const r = o.r0 + (o.r1 - o.r0) * s;
    const c = o.chord(s), t = o.thick(s), b = o.stag(s);
    const z0 = o.zc(s), lx = (o.lean || 0) * s * s;   // 叶尖前掠
    for (let j = 0; j < m; j++) {
      const ph = TAU * j / m;
      const a = 0.5 * Math.cos(ph) * c;          // 弦向
      const q = 0.5 * Math.sin(ph) * t;          // 厚向
      pos.push(lx + a * Math.sin(b) + q * Math.cos(b), r, z0 + a * Math.cos(b) - q * Math.sin(b));
      uv.push(j / m, s);
    }
  }
  for (let i = 0; i < n - 1; i++) {
    for (let j = 0; j < m; j++) {
      const j2 = (j + 1) % m;
      const A = i * m + j, B = i * m + j2, Cc = (i + 1) * m + j2, Dd = (i + 1) * m + j;
      idx.push(A, B, Cc, A, Cc, Dd);
    }
  }
  /* 两端封盖：叶根 / 叶尖各补一个中心点做扇形 */
  const cap = (base, rev) => {
    let cx = 0, cy = 0, cz = 0;
    for (let j = 0; j < m; j++) {
      cx += pos[(base + j) * 3]; cy += pos[(base + j) * 3 + 1]; cz += pos[(base + j) * 3 + 2];
    }
    const ci = pos.length / 3;
    pos.push(cx / m, cy / m, cz / m); uv.push(0.5, rev ? 0 : 1);
    for (let j = 0; j < m; j++) {
      const j2 = (j + 1) % m;
      if (rev) idx.push(ci, base + j2, base + j); else idx.push(ci, base + j, base + j2);
    }
  };
  cap(0, true);
  cap((n - 1) * m, false);
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
  g.setIndex(idx);
  g.computeVertexNormals();
  return g;
}
```

`o` 的字段：`n` 径向段数、`m` 环向段数、`r0/r1` 叶根/叶尖半径、`chord(s)` 弦长函数、`thick(s)` 厚度函数、`stag(s)` 安装角（弧度）、`zc(s)` 轴向位置、`lean` 叶尖前掠量。

### `ringOf` / `stageRing` —— 阵列

```js
function ringOf(geo, count, phase = 0) {
  const arr = [];
  for (let k = 0; k < count; k++) {
    const g = geo.clone();
    g.rotateZ(phase + k * TAU / count);
    arr.push(g);
  }
  const merged = mergeGeometries(arr, false);
  arr.forEach(g => g.dispose());
  return merged;
}
function stageRing(o) {
  const arr = [];
  const base = new THREE.BoxGeometry(o.thick || 0.036, o.height || 0.26, o.chord || 0.26);
  const stag = new THREE.Matrix4().makeRotationY((o.stag || 40) * D2R);
  for (let k = 0; k < o.count; k++) {
    const g = base.clone();
    g.applyMatrix4(stag);                                       // 先绕 Y 预旋
    g.applyMatrix4(new THREE.Matrix4().makeTranslation(0, o.r, 0)); // 推到半径
    g.applyMatrix4(new THREE.Matrix4().makeRotationZ((o.phase || 0) + k * TAU / o.count));
    arr.push(g);
  }
  const merged = mergeGeometries(arr, false);
  arr.forEach(g => g.dispose());
  base.dispose();
  return merged;
}
```

> `stageRing` 用盒子代替真实叶型——压气机/涡轮单级齿数 30~48，用 `bladeGeo` 会拖慢渲染。**顺序不可颠倒**：先 `rotationY` 预旋、再 `translate` 到半径、最后 `rotationZ` 阵列。反过来预旋轴会歪。

---

## 三、26 个构建块逐块参数

### 01 进气整流罩（短舱模式）
```js
const g = new THREE.Group();
/* 唇口与罩体分段建模：6.06–5.865 是金属唇口，5.865–4.56 是复材罩体。
   两段只相邻不重叠，否则同半径共面会产生 z-fighting（拉链状锯齿）。 */
const m = matPaint(true);
g.add(new THREE.Mesh(shellGeo(sliceP(NAC_OUT, 5.865, 4.56), sliceP(NAC_IN, 5.865, 4.56), 160), m));
const lipMat = new THREE.MeshStandardMaterial({
  color: 0xD3DAE2, metalness: 0.97, roughness: 0.19, side: THREE.DoubleSide
});
CLIP_MATS.push(lipMat);
g.add(new THREE.Mesh(shellGeo(sliceP(NAC_OUT, 6.06, 5.860), sliceP(NAC_IN, 6.06, 5.860), 160), lipMat));
/* 后安装边：比罩体内收一点，避免凸出 */
const ringMat = matSteel(C.steelMid, 0.9, 0.32, true);
g.add(new THREE.Mesh(tubeShell(4.60, 4.56, 4.268, 4.256, 0.075, 140), ringMat));
addPart('01', g, [0.0, 3.3, 1.2], [0, 3.9, 5.4]);
```

### 02 进气道声衬
```js
const m = matStd(0xBCC3CC, 0.15, 0.92, { map: perfTexture() });
const cyl = new THREE.Mesh(new THREE.CylinderGeometry(3.582, 3.582, 1.34, 112, 1, true), m);
cyl.rotation.x = Math.PI / 2;      // 轴从 +Y 转到 +Z
cyl.position.z = 5.22;
addPart('02', g, [0.0, 2.9, 2.6], [2.4, 3.5, 5.15]);
```

### 03 旋转整流锥
```js
const m = matStd(0xFFFFFF, 0.10, 0.42, { map: spiralTexture() });
const prof = [[5.96,0.025],[5.88,0.13],[5.74,0.31],[5.55,0.51],[5.31,0.71],
              [5.03,0.89],[4.76,1.02],[4.50,1.10],[4.32,1.13]];
g.add(new THREE.Mesh(latheGeo(prof, 84), m));
const capMat = matSteel(C.silver, 0.95, 0.24);
const cap = new THREE.Mesh(new THREE.SphereGeometry(0.095, 18, 12), capMat);
cap.position.z = 5.95; cap.scale.z = 0.7;
/* 注意：底色是 0xFFFFFF 但贴图 spiralTexture 的底色是 #2A2E34，
   实际呈深色锥 + 白螺旋——这是材质色 × 贴图色的正确叠加结果 */
addPart('03', g, [0.0, 0.0, 6.2], [0, 0, 5.7]);
```

### 04 风扇叶片（18 片宽弦 + 钛前缘）
```js
/* 实拍里叶片受光后偏银灰，前缘包边最亮；基体仍是深色复材 */
const m = new THREE.MeshPhysicalMaterial({
  color: 0x596370, roughness: 0.34, metalness: 0.55,
  clearcoat: 0.35, clearcoatRoughness: 0.3, side: THREE.DoubleSide
});
const bg = bladeGeo({
  n: 20, m: 24, r0: 1.10, r1: 3.36,
  chord: s => 1.62 + 0.30 * s - 0.30 * s * s,     // 中段最宽
  thick: s => 0.24 - 0.170 * s,                   // 叶尖变薄
  stag:  s => (30 + 38 * Math.pow(s, 0.78)) * D2R, // 叶根 30° → 叶尖 68°
  zc:    s => 4.54 + 0.44 * s * s - 0.06 * s,
  lean: 0.20                                       // 叶尖前掠
});
g.add(new THREE.Mesh(ringOf(bg, 18), m));

// 钛合金前缘包边（实拍最亮的一条）：沿同一型线取前缘点做管
const lePts = [];
for (let i = 0; i < 16; i++) {
  const s = i / 15;
  const r = 1.10 + 2.26 * s;
  const c = 1.62 + 0.30 * s - 0.30 * s * s;
  const b = (30 + 38 * Math.pow(s, 0.78)) * D2R;
  const z = 4.54 + 0.44 * s * s - 0.06 * s;
  const lx = 0.20 * s * s;
  lePts.push(new THREE.Vector3(lx - 0.5 * c * Math.sin(b), r, z - 0.5 * c * Math.cos(b)));
}
const tube = new THREE.TubeGeometry(new THREE.CatmullRomCurve3(lePts), 28, 0.036, 7, false);
const leMat = new THREE.MeshStandardMaterial({ color: 0xDCE3EA, metalness: 0.98, roughness: 0.16, side: THREE.DoubleSide });
g.add(new THREE.Mesh(ringOf(tube, 18), leMat));
addPart('04', g, [0.0, 0.0, 4.4], [2.9, 2.1, 4.5]);
```
> 前缘点的取法必须与 `bladeGeo` 里 `a = -0.5c` 那一侧一致（`-0.5*c*sin(b)`），否则包边会贴到后缘上。

### 05 风扇盘与叶根平台
```js
const m = matSteel(C.steelMid, 0.9, 0.34);
g.add(new THREE.Mesh(latheGeo([[5.10,1.14],[5.06,1.18],[4.30,1.18],[4.16,1.11],
                               [4.16,0.95],[4.42,0.91],[5.02,0.94],[5.10,1.02]], 84), m));
const plat = matSteel(0x6E7885, 0.85, 0.42);
g.add(new THREE.Mesh(tubeShell(5.02, 4.10, 1.185, 1.175, 0.045, 96), plat));
for (let k = 0; k < 18; k++) {                    // 榫槽凸块
  const a = k * TAU / 18;
  g.add(box(0.10, 0.10, 0.11, m, Math.cos(a)*1.10, Math.sin(a)*1.10, 5.10));
}
addPart('05', g, [0.0, 0.0, 2.8], [0, 1.15, 4.65]);
```

### 06 风扇机匣（黑碳纤维编织）
```js
const m = matStd(C.carbon2, 0.30, 0.56, { map: TEX.carbon, side: THREE.DoubleSide });
CLIP_MATS.push(m);
g.add(new THREE.Mesh(shellGeo(FANCASE, FANCASE_IN, 168), m));
const rub = matStd(0x545C66, 0.20, 0.92);        // 内壁可磨耗涂层
g.add(new THREE.Mesh(tubeShell(5.30, 3.50, 3.449, 3.436, 0.03, 140), rub));
const fl = matSteel(C.steel, 0.94, 0.26, true);  // 前后法兰
g.add(new THREE.Mesh(tubeShell(5.46, 5.38, 3.572, 3.568, 0.11, 168), fl));
g.add(new THREE.Mesh(tubeShell(3.38, 3.32, 3.518, 3.506, 0.11, 168), fl));
addPart('06', g, [0.0, 2.7, 1.1], [0, -3.70, 4.30]);
```

### 07 机匣箍带（4 道）+ 纵向条 + 紧固件
```js
const bandMat = new THREE.MeshStandardMaterial({
  color: 0xE6EBF0, metalness: 0.96, roughness: 0.18, side: THREE.DoubleSide
});
bandMat.map = TEX.brushed;
bandMat.map.repeat.set(2, 1);
CLIP_MATS.push(bandMat);
/* 前两道窄而靠得近，后两道明显更宽——按实拍位置 */
const bands = [[5.20, 5.09], [5.02, 4.91], [4.54, 4.32], [4.26, 4.02]];
bands.forEach(([zHi, zLo]) => {
  const rHi = sampleR(FANCASE, zHi) + 0.012;
  const rLo = sampleR(FANCASE, zLo) + 0.012;
  const out = [[zHi, rHi], [zHi-0.018, rHi+0.060], [zLo+0.018, rLo+0.060], [zLo, rLo]];
  const inn = [[zHi, rHi-0.030], [zHi-0.018, rHi+0.032], [zLo+0.018, rLo+0.032], [zLo, rLo-0.030]];
  g.add(new THREE.Mesh(shellGeo(out, inn, 168), bandMat));
  /* 箍带端头搭接块：贴着箍带外表面放，中心抬到带面 + 半厚，避免一半陷进去 */
  g.add(box(0.13, 0.10, Math.abs(zHi - zLo) * 0.55, matSteel(0xAEB7C2, 0.92, 0.28),
    Math.cos(0.62) * (rHi + 0.060 + 0.050), Math.sin(0.62) * (rHi + 0.060 + 0.050),
    (zHi + zLo) / 2, 0, 0, 0.62));
});
/* 纵向加强条：贴在机匣面上，只做 6 条 */
const stripMat = matSteel(0xA9B2BD, 0.90, 0.34, true);
[0.30, 1.02, 1.92, 2.86, 3.90, 5.05].forEach(a => {
  const r = sampleR(FANCASE, 4.20) + 0.022;
  g.add(box(0.024, 0.078, 1.66, stripMat, Math.cos(a)*r, Math.sin(a)*r, 4.34, 0, 0, a));
});
/* 紧固件点阵——必须随壳体一起被裁剪，否则切面外会留下悬空黑点。
   半径收在短舱内壁（≈3.64）以内，避免装机状态从罩体里戳出来。 */
const boltMat = matSteel(0x555F6B, 0.88, 0.44, true);
g.add(boltRing(5.13, 3.560, 56, 0.014, boltMat));
g.add(boltRing(4.97, 3.556, 56, 0.014, boltMat));
g.add(boltRing(4.45, 3.552, 60, 0.016, boltMat));
g.add(boltRing(4.13, 3.548, 60, 0.016, boltMat));
addPart('07', g, [0.0, 3.3, 1.1], [0, 3.72, 4.35]);
```

### 08 出口导流叶片（22 片）
```js
const m = matSteel(C.steel, 0.86, 0.36);
/* 叶尖半径必须小于风扇机匣内壁，且整片叶必须落在机匣型线的 z 范围内
   （FANCASE 只到 z=3.34）。原先放在 z=3.02——那已经在机匣之外，
   叶尖悬空朝前戳出，从侧面看就是一排三角尖刺。 */
const OGV_Z = 3.66;
const vg = bladeGeo({
  n: 8, m: 12, r0: 2.24, r1: sampleR(FANCASE_IN, OGV_Z) - 0.020,
  chord: () => 0.60, thick: () => 0.068,
  stag: s => (8 + 5 * s) * D2R,
  zc: () => OGV_Z
});
g.add(new THREE.Mesh(ringOf(vg, 22, 0.14), m));
addPart('08', g, [0.0, 0.0, 1.5], [2.6, 3.15, 3.5]);
```
> `r1` 必须写成 `sampleR(FANCASE_IN, OGV_Z) - 0.020`，不能写死数字——型线一改就自动跟随。

### 09 风扇整流罩（短舱模式）
```js
const m = matPaint(true);
g.add(new THREE.Mesh(shellGeo(sliceP(NAC_OUT, 4.44, 1.66), sliceP(NAC_IN, 4.44, 1.66), 160), m));
const dm = matSteel(C.steelMid, 0.8, 0.4, true);
g.add(new THREE.Mesh(tubeShell(4.30, 1.80, 4.28, 4.13, 0.10, 96), dm));
const seamMat = matStd(0x6E7681, 0.5, 0.55);
g.add(new THREE.Mesh(tubeShell(4.62, 4.40, 4.16, 4.14, 0.16, 96), seamMat));
g.add(new THREE.Mesh(tubeShell(1.74, 1.48, 4.06, 4.04, 0.16, 96), seamMat));
addPart('09', g, [0.0, 2.6, 0.1], [-3.95, 1.7, 2.6]);
```

### 10 反推平移套筒（短舱模式）
```js
const m = matPaint(true);
g.add(new THREE.Mesh(shellGeo(sliceP(NAC_OUT, 1.54, -1.80), sliceP(NAC_IN, 1.54, -1.80), 160), m));
const ringMat = matSteel(C.steelMid, 0.88, 0.32, true);
g.add(new THREE.Mesh(tubeShell(1.54, 1.48, 4.15, 4.14, 0.12, 140), ringMat));
g.add(new THREE.Mesh(tubeShell(-1.72, -1.79, 3.98, 3.96, 0.12, 140), ringMat));
const fMat = matPaint2(true);
[Math.PI * 1.24, Math.PI * 1.76].forEach(a => {      // 两个作动筒整流包
  const b = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.46, 2.0), fMat);
  b.position.set(Math.cos(a) * 4.06, Math.sin(a) * 4.06, -0.4);
  b.rotation.z = a;
  g.add(b);
});
addPart('10', g, [0.0, 2.1, -1.3], [3.95, 0.8, -0.6]);
```

### 11 外涵尾喷口（短舱模式）
```js
const m = matPaint2(true);
g.add(new THREE.Mesh(shellGeo(sliceP(NAC_OUT, -1.92, -4.35), sliceP(NAC_IN, -1.92, -4.35), 160), m));
const lipMat = matSteel(C.steelMid, 0.9, 0.3, true);
g.add(new THREE.Mesh(shellGeo(sliceP(NAC_OUT, -4.28, -4.35), sliceP(NAC_IN, -4.28, -4.35), 160), lipMat));
g.add(new THREE.Mesh(tubeShell(-1.76, -1.96, 3.88, 3.86, 0.16, 96), matStd(0x6E7681, 0.5, 0.55)));
addPart('11', g, [0.0, 1.6, -2.6], [2.9, -2.4, -3.8]);
```

### 12 核心机罩（深色机械区 + 法兰 + 安装边 + 口盖）
```js
/* 实拍里风扇机匣之后到涡轮后机匣之间是深色、密集的机械区，
   不是一片浅灰光筒——这里压深作底，让银色管路跳出来 */
const m = new THREE.MeshStandardMaterial({
  color: 0x4A525C, roughness: 0.72, metalness: 0.34, side: THREE.DoubleSide
});
CLIP_MATS.push(m);
g.add(new THREE.Mesh(shellGeo(sliceP(CORE_OUT, 3.40, -4.95), sliceP(CORE_IN, 3.40, -4.95), 132), m));

/* 前段浅色承力环（实拍风扇后那圈发亮的径向支板段） */
const hubFrame = matSteel(0xADB6C1, 0.86, 0.36, true);
g.add(new THREE.Mesh(tubeShell(3.36, 2.92, 2.395, 2.386, 0.055, 132), hubFrame));
for (let k = 0; k < 24; k++) {
  const a = k * TAU / 24;
  /* 凸耳：切向要足够宽（0.13），否则轴向 0.40 的薄片侧看像刀尖 */
  g.add(box(0.058, 0.130, 0.34, hubFrame,
    Math.cos(a) * (sampleR(CORE_OUT, 3.14) + 0.012),
    Math.sin(a) * (sampleR(CORE_OUT, 3.14) + 0.012), 3.14, 0, 0, a));
}
/* 分段法兰环 */
const flMat = matSteel(0x8A939F, 0.88, 0.38, true);
[1.55, 0.10, -1.70, -3.40].forEach(z => {
  const r = sampleR(CORE_OUT, z);
  g.add(new THREE.Mesh(tubeShell(z + 0.042, z - 0.042, r + 0.018, r + 0.016, 0.030, 128), flMat));
});
/* 纵向安装边：核心机罩是锥面（2.42 → 1.80）。定半径直条会两端悬空，
   盒子拼接会在锥面错位露三角锯齿——直接按型线放样成连续条带。 */
const railMat = matSteel(0x8E97A3, 0.85, 0.42, true);
[0.30, Math.PI - 0.30].forEach(a => {
  g.add(surfStrip(CORE_OUT, a, 2.80, -4.60, 0.013, 0.030, railMat, 56));
});
/* 检修口盖：比例必须是"宽 × 高 × 薄"，不是"长 × 细 × 薄"——
   早先写成轴向 0.52 / 切向 0.055，就成了从罩体侧面斜插出来的一把刀。 */
const doorMat = matSteel(0x6E7885, 0.72, 0.52, true);
[[0.60, 1.55], [-1.20, 1.70], [-3.05, 0.90]].forEach(([z, ang]) => {
  const r = sampleR(CORE_OUT, z) + 0.010;
  g.add(box(0.016, 0.34, 0.46, doorMat, Math.cos(ang) * r, Math.sin(ang) * r, z, 0, 0, ang));
});
addPart('12', g, [0.0, -2.7, -0.3], [0, -2.5, -1.4]);
```

### 13 增压级（3 级）
```js
const m = matSteel(C.steelMid, 0.85, 0.4);
g.add(new THREE.Mesh(shellGeo(
  [[3.62,1.76],[3.20,1.74],[2.60,1.66],[2.44,1.58]],
  [[3.62,1.68],[3.20,1.66],[2.60,1.58],[2.44,1.50]], 100), m));
const bm = matSteel(C.ti, 0.9, 0.32);
const zs = [3.42, 3.06, 2.72], rs = [1.50, 1.47, 1.45];
zs.forEach((z, i) => {
  const mesh = new THREE.Mesh(stageRing({ count: 34, r: rs[i], chord: 0.25,
    height: 0.26, thick: 0.036, stag: 40 }), bm);
  mesh.position.z = z;
  g.add(mesh);
});
addPart('13', g, [0.0, 0.0, 0.9], [0, 1.55, 3.2]);
```

### 14 高压压气机（10 级，转子 + 静子交替）
```js
const m = matSteel(C.steel, 0.88, 0.36);
g.add(new THREE.Mesh(shellGeo(
  [[2.42,1.58],[1.90,1.54],[1.20,1.46],[0.40,1.36],[-0.30,1.27],[-0.98,1.18]],
  [[2.42,1.50],[1.90,1.46],[1.20,1.38],[0.40,1.28],[-0.30,1.20],[-0.98,1.11]], 100), m));
const rotorMat = matSteel(C.ti, 0.92, 0.28);
const statorMat = matSteel(0x9AA4B1, 0.82, 0.44);
for (let i = 0; i < 10; i++) {
  const t = i / 9;
  const z = lerp(2.30, -0.80, t);
  const r = lerp(1.42, 1.13, t);
  const h = lerp(0.28, 0.17, t);
  const rot = new THREE.Mesh(stageRing({ count: 30, r: r - 0.01,
    chord: lerp(0.24, 0.15, t), height: h, thick: 0.032, stag: 44 }), rotorMat);
  rot.position.z = z;
  g.add(rot);
  if (i < 9) {
    const st = new THREE.Mesh(stageRing({ count: 34, r: r - 0.06,
      chord: lerp(0.20, 0.13, t), height: h * 0.9, thick: 0.028, stag: 30 }), statorMat);
    st.position.z = z - 0.155;
    g.add(st);
  }
}
const fl = matSteel(C.steelMid, 0.9, 0.3, true);
[2.36, 1.62, 0.86, 0.10].forEach(z => {
  g.add(new THREE.Mesh(tubeShell(z+0.048, z-0.048,
    sampleR([[2.42,1.585],[-0.98,1.19]], z) + 0.028,
    sampleR([[2.42,1.585],[-0.98,1.19]], z) + 0.024, 0.05, 100), fl));
});
addPart('14', g, [0.0, 0.0, -0.4], [0, 1.35, 0.5]);
```

### 15 TAPS II 燃烧室
```js
const m = matSteel(C.hot, 0.78, 0.46);
g.add(new THREE.Mesh(shellGeo(
  [[-1.02,1.44],[-1.18,1.50],[-1.55,1.53],[-1.92,1.48],[-2.10,1.38]],
  [[-1.02,1.38],[-1.18,1.44],[-1.55,1.47],[-1.92,1.42],[-2.10,1.32]], 100), m));
const linerMat = matStd(0xB08A62, 0.7, 0.5);      // 火焰筒内外壁
g.add(new THREE.Mesh(latheGeo([[-1.06,1.18],[-1.32,1.10],[-1.72,1.10],[-1.98,1.16]], 100), linerMat));
g.add(new THREE.Mesh(latheGeo([[-1.06,0.96],[-1.32,1.00],[-1.72,1.00],[-1.98,0.96]], 100), linerMat));
g.add(box(0.20, 0.30, 0.22, m, 1.46, 0.0, -1.55));  // 侧面凸出件
addPart('15', g, [0.0, 0.0, -1.6], [0, 1.5, -1.6]);
```

### 16 燃油喷嘴（18 个）
```js
const m = matSteel(0x8B8F96, 0.9, 0.36);
const stem = new THREE.CylinderGeometry(0.062, 0.062, 0.34, 10);
const nut  = new THREE.CylinderGeometry(0.115, 0.115, 0.10, 6);
nut.translate(0, 0.14, 0);
const tip  = new THREE.ConeGeometry(0.055, 0.12, 10);
tip.rotateX(Math.PI);
tip.translate(0, -0.20, 0);
const one = mergeGeometries([stem, nut, tip], false);
one.translate(0, 1.50, 0);        // 整组抬到火焰筒半径
g.add(new THREE.Mesh(ringOf(one, 18, 0.17), m));
addPart('16', g, [0.0, 1.3, -1.6], [1.65, 1.35, -1.35]);
```

### 17 高压涡轮（2 级 + CMC 罩环）
```js
const m = matSteel(C.hot, 0.82, 0.42);
g.add(new THREE.Mesh(shellGeo(
  [[-2.06,1.45],[-2.40,1.50],[-2.80,1.52],[-3.06,1.47]],
  [[-2.06,1.39],[-2.40,1.44],[-2.80,1.46],[-3.06,1.41]], 100), m));
const bMat = matSteel(0xB39A7C, 0.85, 0.36);
[2.26, 2.78].forEach(z => {
  const r = new THREE.Mesh(stageRing({ count: 46, r: 1.30, chord: 0.22,
    height: 0.30, thick: 0.034, stag: 52 }), bMat);
  r.position.z = -z;
  g.add(r);
});
const cmc = matStd(C.cmc, 0.25, 0.74);
g.add(new THREE.Mesh(tubeShell(-2.10, -3.02, 1.40, 1.40, 0.07, 100), cmc));
addPart('17', g, [0.0, 0.0, -2.6], [0, 1.35, -2.55]);
```

### 18 低压涡轮（5 级）
```js
const m = matSteel(C.steelMid, 0.84, 0.42);
g.add(new THREE.Mesh(shellGeo(
  [[-3.12,1.56],[-3.80,1.60],[-4.60,1.62],[-5.20,1.57],[-5.55,1.49]],
  [[-3.12,1.49],[-3.80,1.53],[-4.60,1.55],[-5.20,1.50],[-5.55,1.42]], 100), m));
const bMat = matSteel(0xA7B1BD, 0.86, 0.38);
for (let i = 0; i < 5; i++) {
  const t = i / 4;
  const rg = new THREE.Mesh(stageRing({ count: 48, r: lerp(1.40, 1.52, t),
    chord: 0.26, height: 0.32, thick: 0.03, stag: 56 }), bMat);
  rg.position.z = lerp(-3.36, -5.10, t);
  g.add(rg);
}
addPart('18', g, [0.0, 0.0, -3.7], [0, 1.45, -4.3]);
```

### 19 涡轮后机匣肋环（6 道深浅交替）
```js
const ribMat = new THREE.MeshStandardMaterial({
  color: 0xD2D9E1, metalness: 0.95, roughness: 0.20, side: THREE.DoubleSide
});
ribMat.map = TEX.brushedDark;
CLIP_MATS.push(ribMat);
/* 一深一浅的环形加强肋，套在核心机罩尾段外侧（实拍最像"一摞盘"） */
const prof = [
  [-4.98,1.800], [-5.05,1.905], [-5.12,1.800],
  [-5.19,1.910], [-5.26,1.795],
  [-5.33,1.900], [-5.40,1.790],
  [-5.47,1.885], [-5.54,1.775],
  [-5.61,1.870], [-5.68,1.755],
  [-5.75,1.840], [-5.82,1.720]
];
g.add(new THREE.Mesh(latheGeo(prof, 128), ribMat));
const fl = matSteel(0xB9C1CB, 0.92, 0.26, true);   // 端面法兰
g.add(new THREE.Mesh(tubeShell(-4.94, -4.88, 1.815, 1.800, 0.09, 128), fl));
const sm = matSteel(C.steel, 0.9, 0.32);            // 6 根支板
for (let k = 0; k < 6; k++) {
  const a = k * TAU / 6 + 0.2;
  g.add(box(0.46, 0.09, 0.30, sm, Math.cos(a) * 1.60, Math.sin(a) * 1.60, -5.86, 0, 0, a));
}
addPart('19', g, [0.0, 0.0, -4.7], [0, 1.86, -5.40]);
```

### 20 尾锥
```js
const m = matSteel(C.steelMid, 0.86, 0.4);
g.add(new THREE.Mesh(shellGeo([[-5.92,1.44],[-6.10,1.40]], [[-5.92,1.36],[-6.10,1.32]], 100), m));
const plugMat = matSteel(C.silver, 0.90, 0.30);
g.add(new THREE.Mesh(latheGeo([[-6.05,1.30],[-6.42,1.18],[-6.90,0.86],
                               [-7.22,0.42],[-7.36,0.03]], 84), plugMat));
addPart('20', g, [0.0, 0.0, -5.8], [0, 0.15, -7.1]);
```

### 21 附件齿轮箱
```js
const m = matSteel(C.steelDark, 0.70, 0.50);
g.add(box(1.42, 0.94, 1.86, m, 0, -2.44, 1.96));    // 主箱体
g.add(box(0.78, 0.50, 0.96, m, 0.44, -2.98, 1.66)); // 下凸台
const shaftMat = matSteel(C.steelMid, 0.92, 0.30);
const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.105, 0.105, 1.24, 12), shaftMat);
shaft.position.set(0, -1.82, 2.44);
shaft.rotation.x = 0.42;                             // 径向传动轴斜插
g.add(shaft);
const gear = new THREE.Mesh(new THREE.CylinderGeometry(0.31, 0.31, 0.15, 22), shaftMat);
gear.position.set(0, -2.40, 2.06);
gear.rotation.x = Math.PI / 2;                       // 齿轮盘面朝 +Z
g.add(gear);
for (let k = 0; k < 4; k++) {                        // 铸件加强筋
  g.add(box(0.09, 0.30, 1.70, m, -0.55 + k * 0.36, -1.99, 1.96));
}
addPart('21', g, [0.0, -2.9, 1.3], [0.9, -3.0, 2.1]);
```

### 22 附件泵组与油滤（含红色端盖）
```js
const pMat = matSteel(C.steel, 0.90, 0.32);
[[0.52, -2.72, 1.90], [-0.40, -2.72, 1.90]].forEach(([x, y, z]) => {  // 泵体
  const p = new THREE.Mesh(new THREE.CylinderGeometry(0.175, 0.175, 0.46, 16), pMat);
  p.position.set(x, y, z);
  p.rotation.z = Math.PI / 2;      // 轴转到 X（横向卧放）
  g.add(p);
});
/* 红盖油滤——实拍识别点 */
const capMat = matStd(C.red, 0.35, 0.42);
const filt = new THREE.Mesh(new THREE.CylinderGeometry(0.30, 0.30, 0.30, 22), pMat);
filt.position.set(0.05, -2.42, 2.86);
filt.rotation.x = Math.PI / 2;     // 轴转到 Z（朝前）
g.add(filt);
const fc = new THREE.Mesh(new THREE.CylinderGeometry(0.245, 0.245, 0.10, 22), capMat);
fc.position.set(0.05, -2.42, 3.02);
fc.rotation.x = Math.PI / 2;
g.add(fc);
/* 起动机 / 发电机 */
const gen = new THREE.Mesh(new THREE.CylinderGeometry(0.34, 0.30, 0.86, 20),
  matSteel(C.steelMid, 0.88, 0.34));
gen.position.set(-0.72, -2.10, 1.34);
gen.rotation.z = Math.PI / 2;
gen.rotation.y = 0.28;
g.add(gen);
addPart('22', g, [0.0, -3.4, 1.7], [0.9, -3.1, 2.7]);
```

### 23 S 型引气管（核心机顶部两根粗银管）
```js
/* 实拍这两根引气管是明亮的哑光不锈钢，不能给高 metalness + 贴图，
   否则在浅色环境里会反射成深灰近黑 */
const pipeMat = new THREE.MeshStandardMaterial({
  color: 0xD8DEE5, metalness: 0.55, roughness: 0.30, side: THREE.DoubleSide
});
/* 贴在核心机罩顶部外表面走，两根并行，向前端弯成 S */
const duct = (angOff, rad, zStart, zEnd) => {
  const pts = [];
  const N = 8;
  for (let i = 0; i < N; i++) {
    const t = i / (N - 1);
    const z = lerp(zStart, zEnd, t);
    const r = sampleR(CORE_OUT, z) + 0.20 + 0.30 * Math.sin(t * Math.PI * 0.9);
    const a = Math.PI / 2 + angOff * (1 - 0.28 * t);
    pts.push(new THREE.Vector3(Math.cos(a) * r, Math.sin(a) * r, z));
  }
  return new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 70, rad, 12, false), pipeMat);
};
g.add(duct(0.135, 0.132, 2.28, -1.30));
g.add(duct(-0.135, 0.132, 2.24, -1.36));
/* 管接头 / 卡箍
   管子大致沿 Z 走，TorusGeometry 默认就躺在 XY 平面（法线 +Z），
   正好套住管身。之前写成 rotation.set(0, π/2, a) 会把环立起来，
   从侧面看像插在管子上的一片刀。 */
const clampMat = matSteel(C.steelDark, 0.9, 0.36);
[[0.135, 1.55], [-0.135, 1.55], [0.135, 0.30], [-0.135, 0.30]].forEach(([ao, z]) => {
  const r = sampleR(CORE_OUT, z) + 0.20 + 0.30 * Math.sin(((2.28 - z) / 3.58) * Math.PI * 0.9);
  const a = Math.PI / 2 + ao;
  const t = new THREE.Mesh(new THREE.TorusGeometry(0.146, 0.028, 6, 16), clampMat);
  t.position.set(Math.cos(a) * r, Math.sin(a) * r, z);
  g.add(t);
});
addPart('23', g, [0.0, 2.3, -0.3], [0.30, 2.34, 0.20]);
```

### 24 管路与线束（最密的一块）
```js
const g = new THREE.Group();
const steelPipe = matSteel(C.steel, 0.92, 0.28);
const redHose = matStd(C.red, 0.22, 0.62, { metalness: 0.22 });
const orgHose = matStd(C.orange, 0.22, 0.62, { metalness: 0.22 });
const wireMat = matStd(C.wire, 0.25, 0.72);

/* 细钢管：贴着核心机罩外表面绕行（半径取机型线 + 间隙，保证露在外面） */
const CLR = 0.075;
const specs = [
  { a0: 0.62, a1: 0.78, z0: 2.30, z1: -1.60, rad: 0.040, wave: 0.05 },
  { a0: 1.12, a1: 1.36, z0: 2.20, z1: -2.40, rad: 0.033, wave: 0.045 },
  { a0: 2.32, a1: 2.12, z0: 2.24, z1: -2.10, rad: 0.037, wave: 0.06 },
  { a0: 3.38, a1: 3.56, z0: 2.30, z1: -1.90, rad: 0.031, wave: 0.045 },
  { a0: 4.32, a1: 4.12, z0: 2.20, z1: -2.30, rad: 0.035, wave: 0.05 },
  { a0: 5.32, a1: 5.56, z0: 2.26, z1: -1.70, rad: 0.029, wave: 0.04 },
  { a0: 0.98, a1: 1.04, z0: 1.20, z1: -3.40, rad: 0.027, wave: 0.045 },
  { a0: 2.70, a1: 2.90, z0: 2.10, z1: -3.20, rad: 0.026, wave: 0.05 },
  { a0: 4.75, a1: 4.92, z0: 2.18, z1: -2.90, rad: 0.024, wave: 0.04 },
  { a0: 1.75, a1: 1.62, z0: 2.26, z1: -2.60, rad: 0.022, wave: 0.035 },
  { a0: 5.70, a1: 5.88, z0: 2.22, z1: -1.40, rad: 0.025, wave: 0.04 },
  { a0: 3.90, a1: 4.02, z0: 2.28, z1: -3.00, rad: 0.021, wave: 0.03 }
];
specs.forEach((s, i) => {
  const o = Object.assign({ n: 9, mat: steelPipe, waveN: 2, tub: 7 }, s);
  o.r0 = sampleR(CORE_OUT, s.z0) + CLR + (i % 3) * 0.028;
  o.r1 = sampleR(CORE_OUT, s.z1) + CLR + (i % 3) * 0.028;
  o.off = 0;
  g.add(wrapPipe(o));
});

/* 红色软管：从附件齿轮箱出来，贴核心机罩侧下方向后绕 */
const hose = (seg, rad, mat) => pathPipe(seg.map(p => {
  const r = sampleR(CORE_OUT, p[2]) + CLR + p[3];
  return [Math.cos(p[0]) * r, Math.sin(p[0]) * r, p[2]];
}), rad, mat, 10, 66);
g.add(hose([
  [1.05,0,2.30,0.16],[1.32,0,1.90,0.08],[1.46,0,1.10,0.05],
  [1.44,0,0.20,0.05],[1.30,0,-0.80,0.06],[1.10,0,-1.80,0.07]
], 0.058, redHose));
g.add(hose([
  [0.82,0,2.26,0.18],[1.06,0,1.84,0.09],[1.20,0,1.02,0.05],
  [1.18,0,0.10,0.05],[1.04,0,-0.90,0.06],[0.86,0,-1.90,0.07]
], 0.052, orgHose));
g.add(hose([
  [-0.90,0,2.28,0.10],[-1.16,0,1.70,0.06],[-1.26,0,0.80,0.05],
  [-1.20,0,-0.20,0.05],[-1.04,0,-1.10,0.06],[-0.88,0,-1.96,0.07]
], 0.046, steelPipe));

/* FADEC 线束（成束细管，沿核心机下方走） */
[[3.02,0,1.92,0.07],[3.16,0,0.60,0.06],[3.34,0,-0.60,0.06],[3.50,0,-1.80,0.07]],
[[3.22,0,1.86,0.07],[3.36,0,0.54,0.06],[3.54,0,-0.66,0.06],[3.70,0,-1.86,0.07]],
[[3.42,0,1.80,0.07],[3.56,0,0.48,0.06],[3.74,0,-0.72,0.06],[3.90,0,-1.92,0.07]]
  .forEach(b => g.add(hose(b, 0.022, wireMat)));

/* 卡箍 / 支架：切向加宽到 0.18，轴向收到 0.22，免得侧看是一条刀锋 */
const brMat = matSteel(C.steelDark, 0.85, 0.40);
[2.05, 1.10, 0.10, -0.90, -1.90].forEach((z, i) => {
  const a = 0.62 + i * 1.02;
  const r = sampleR(CORE_OUT, z) + 0.045;
  g.add(box(0.075, 0.180, 0.22, brMat, Math.cos(a)*r, Math.sin(a)*r, z, 0, 0, a));
});

/* ---- 凸出的附件块：泵体 / 阀块 / 接线盒 / 作动器 ----
   实拍核心机之所以显得"密"，一大半来自这些凸出机体，
   而不是单靠细管路。这里按方位铺一批不同体积的块体。 */
const castMat = matSteel(0x6B7480, 0.62, 0.56);
const castDk  = matSteel(0x4B535E, 0.58, 0.62);
const alloyMat = matSteel(0xA8B1BC, 0.88, 0.34);
const boxAt = (z, ang, w, h, d, mat, out) => {
  const r = sampleR(CORE_OUT, z) + (out || 0.06) + h * 0.5;
  /* 注意参数顺序：box(径向厚度, 切向宽度, 轴向长度)，旋转角必须是 ang */
  const b = box(h, w, d, mat, Math.cos(ang) * r, Math.sin(ang) * r, z, 0, 0, ang);
  g.add(b);
  return b;
};
boxAt(1.86, 2.42, 0.66, 0.56, 0.86, castMat, 0.02);   // 燃油计量装置（最大）
boxAt(1.42, 2.52, 0.44, 0.40, 0.52, castDk, 0.02);
boxAt(0.92, 2.36, 0.38, 0.34, 0.46, castMat, 0.03);
boxAt(1.72, 3.86, 0.52, 0.44, 0.62, castMat, 0.02);   // 起动机 / 引气阀
boxAt(1.16, 3.98, 0.34, 0.30, 0.40, alloyMat, 0.03);
boxAt(0.64, 1.62, 0.30, 0.26, 0.44, alloyMat, 0.03);  // FADEC 接线盒
boxAt(-0.62, 1.50, 0.26, 0.22, 0.34, castDk, 0.03);
boxAt(-1.24, 4.62, 0.24, 0.24, 0.50, alloyMat, 0.04); // 中段活门
const act = new THREE.Mesh(new THREE.CylinderGeometry(0.075, 0.075, 0.62, 12), alloyMat);
act.position.set(Math.cos(5.10) * 2.16, Math.sin(5.10) * 2.16, -2.02);
act.rotation.set(0.30, 0, 5.10);
g.add(act);
for (let k = 0; k < 4; k++) {                          // 碎屑排除阀
  boxAt(2.62 - k * 0.10, 4.55 + k * 0.26, 0.16, 0.14, 0.30, castDk, 0.04);
}
/* 管路接头 / 法兰小圆盘
   CylinderGeometry 的轴沿 +Y。要让它平贴圆柱面（法线沿径向），
   只需绕 Z 转 a - π/2：Rz 把 (0,1,0) 映射到 (-sinφ, cosφ, 0)，
   取 φ = a - π/2 即得径向 (cos a, sin a, 0)。
   写成 set(π/2, 0, a) 会让轴落到 +Z 上——圆盘立成薄片，
   从侧面看就是一排楔形尖刺（本版之前的缺陷）。 */
const flangeMat = matSteel(0xB4BDC7, 0.92, 0.28);
[[2.10,0.70],[1.30,1.30],[0.30,0.80],[-0.70,1.30],[-1.70,0.70],[1.90,4.24],[0.10,4.30]]
  .forEach(([z, a]) => {
    const r = sampleR(CORE_OUT, z) + 0.040;
    const d = new THREE.Mesh(new THREE.CylinderGeometry(0.085, 0.085, 0.032, 14), flangeMat);
    d.position.set(Math.cos(a) * r, Math.sin(a) * r, z);
    d.rotation.set(0, 0, a - Math.PI / 2);
    g.add(d);
  });
addPart('24', g, [0.0, -2.5, 0.3], [1.9, -1.7, 0.9]);
```

### 25 安装吊挂（短舱模式）
```js
const g = new THREE.Group();
const shape = new THREE.Shape();
shape.moveTo(2.12, 3.18);
shape.lineTo(1.98, 4.16);
shape.quadraticCurveTo(1.86, 4.62, 1.45, 4.92);
shape.quadraticCurveTo(1.12, 5.14, 0.55, 5.18);
shape.lineTo(-0.75, 5.22);
shape.quadraticCurveTo(-1.35, 5.20, -1.72, 4.86);
shape.quadraticCurveTo(-2.12, 4.44, -2.18, 3.18);
shape.lineTo(2.12, 3.18);
const geo = new THREE.ExtrudeGeometry(shape, {
  depth: 0.46, bevelEnabled: true, bevelSize: 0.08, bevelThickness: 0.05,
  bevelSegments: 2, curveSegments: 12
});
geo.translate(0, 0, -0.26);
const py = new THREE.Mesh(geo, matPaint2(false));
py.rotation.y = -Math.PI / 2;      // Shape 在 XY 平面挤出，转到 YZ 剖面
g.add(py);
const lm = matSteel(C.steelDark, 0.85, 0.36);
g.add(box(0.60, 0.24, 0.30, lm, 0, 4.32, 1.30));   // 前后梁接头
g.add(box(0.60, 0.24, 0.30, lm, 0, 4.32, -1.55));
addPart('25', g, [0.0, 2.0, -1.8], [0, 5.28, -0.4]);
```

### 26 展示台架（裸机模式）
```js
const m = matSteel(0x707A87, 0.72, 0.44);
const base = new THREE.Mesh(new THREE.CylinderGeometry(1.55, 1.72, 0.20, 40), m);
base.position.set(0.0, floorY + 0.10, 0.30);       // floorY = -4.72
g.add(base);
g.add(box(0.62, 2.36, 0.62, m, 0.0, -3.62, 0.30));  // 立柱
g.add(box(1.44, 0.26, 1.30, m, 0.0, -2.42, 0.30));  // 鞍座
const br = matSteel(0x5E6874, 0.75, 0.46);          // 斜撑
[[-1, 1], [1, 1]].forEach(([sx]) => {
  g.add(box(0.14, 0.14, 2.05, br, sx * 0.62, -3.70, 0.30, 0, 0, sx * 0.30));
});
addPart('26', g, [0.0, -4.0, 0.3], [0, -3.80, 0.30]);
```

---

## 四、`addPart` 注册函数

```js
const E = new THREE.Group();
scene.add(E);
const P = {};
function addPart(id, g, ex, anchor) {
  E.add(g);
  const mats = [];
  g.traverse(o => {
    if (!o.isMesh) return;
    o.userData.pid = id;          // 拾取用
    o.castShadow = true;
    o.receiveShadow = true;
    const list = Array.isArray(o.material) ? o.material : [o.material];
    list.forEach(m => {
      if (!mats.includes(m)) {
        /* 记下原始材质状态，供 dimTargets() 还原 */
        m.userData.base = {
          transparent: m.transparent, opacity: m.opacity, depthWrite: m.depthWrite,
          emissive: m.emissive ? m.emissive.clone() : null,
          emissiveIntensity: m.emissiveIntensity !== undefined ? m.emissiveIntensity : 1
        };
        mats.push(m);
      }
    });
  });
  P[id] = {
    group: g, mats,
    ex: new THREE.Vector3(ex[0], ex[1], ex[2]),
    anchor: new THREE.Vector3(anchor[0], anchor[1], anchor[2]),
    el: null                     // 标签 DOM，UI 阶段填
  };
}
```
