# 部署与依赖说明

---

## 一、两种产物形态

| 形态 | 怎么来 | 依赖 | 适用 |
|---|---|---|---|
| **CDN 版**（默认产物） | 按 `SKILL.md` 正常生成 | 需联网（three.js 从 jsDelivr 加载） | 有网环境、体积小（~97 KB） |
| **离线单文件版** | 跑 `scripts/build_offline.py <CDN版>` | 零依赖，双击即开 | 内网 / 演示机 / 断网环境（~1.5 MB） |

**首先生成 CDN 版，再按需转离线版。** 不要直接手写离线版——内联代码会淹没在 1.2 MB 的依赖里，改不动。

---

## 二、依赖清单（已随包附带）

`assets/vendor/` 内已放好 three.js **r160** 的四个文件（合计约 1.28 MB）：

| 文件 | 大小 | 来源 |
|---|---|---|
| `three.module.js` | 1,272,972 B | `https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js` |
| `addons/controls/OrbitControls.js` | 29,868 B | `.../examples/jsm/controls/OrbitControls.js` |
| `addons/environments/RoomEnvironment.js` | 3,735 B | `.../examples/jsm/environments/RoomEnvironment.js` |
| `addons/utils/BufferGeometryUtils.js` | 31,906 B | `.../examples/jsm/utils/BufferGeometryUtils.js` |

三个 addon 内部都只 `from 'three'`，所以内联时把 `'three'` 重写成 three 的 blob URL 即可，**没有其它传递依赖**（已实测确认）。

若 vendor 丢失，重新拉取：

```powershell
powershell -ExecutionPolicy Bypass -File scripts/fetch_vendor.ps1
```

---

## 三、离线版构建

```bash
python scripts/build_offline.py <CDN版.html> [-o 输出.html]
```

默认输出为 `<原名>-离线版.html`。

它做四件事：
1. 删掉 `<script type="importmap">`
2. 把四条静态 `import` 替换为占位注释
3. 注入引导代码：把四个依赖源码内联为字符串 → `URL.createObjectURL` 造 blob → 动态 `import`
4. 标题加「· 离线版」

### 为什么不直接把 vendor 放成相对路径

**实测过，不行。** `file://` 协议下 ES module 的相对路径导入会被 CORS 硬拦截：

```
TypeError: Failed to fetch dynamically imported module: file:///.../vendor/three.module.js
```

加 `--allow-file-access-from-files`、甚至 `--disable-web-security` 都**不能**解决（已逐一实测）。走本地 HTTP 服务可以，但那要求用户会起服务，不符合「双击即开」。

`blob:` URL 的模块导入在 `file://` 下是允许的——这是离线版唯一可行的路径。

---

## 四、运行环境要求

| 项 | 要求 |
|---|---|
| 浏览器 | Chrome / Edge 90+（需支持 importmap、WebGL2、`MeshPhysicalMaterial` clearcoat） |
| GPU | 有硬件加速即可；软件渲染（`--disable-gpu`）也能跑，但阴影会弱 |
| 网络 | CDN 版需要；离线版**完全不需要** |
| 磁盘 | 技能包约 10 MB（含视频与关键帧）；离线产物另计 1.5 MB |

---

## 五、验证工具链

```bash
python scripts/verify.py <产物.html>
```

需要：
- **node**（`node --check` 语法检查）—— 必需
- **Chrome 或 Edge**（无头截图）—— 必需，找不到会降级为警告
- **Pillow**（分解取景量测）—— 可选，缺失时该项降级

安装 Pillow：`pip install Pillow`

---

## 六、目录结构

```
LEAP-1B-发动机/
├── SKILL.md                     技能主文件（工作流 + 铁律 + 边界）
├── references/
│   ├── spec-parts.md            26 部件全表（名称/说明/参数/分解向量/锚点）
│   ├── spec-geometry.md         四条型线 + 12 工具函数 + 26 构建块逐块参数
│   ├── spec-scene.md            场景/材质/贴图/交互/分解取景算法
│   ├── video-analysis.md        视频逐帧观察 → 8 处外形校正推导
│   ├── pitfalls.md              12 条纠错史（症状→根因→修法）
│   └── validation.md            验证四件套
├── assets/
│   ├── leap-1b-reference.mp4    原始实拍视频 4.9 MB / 23.4 s
│   ├── frames/                  13 张关键帧（每 2 s）
│   ├── reference/               4 张成品基准渲染图（裸机/剖视/装机/分解）
│   └── vendor/                  three.js r160 四个文件
└── scripts/
    ├── verify.py                四件套验证
    ├── build_offline.py         离线单文件构建
    └── fetch_vendor.ps1         重新拉取依赖
```

---

## 七、迁移到新环境

1. 整个 `LEAP-1B-发动机/` 目录拷到目标机的 `~/.workbuddy/skills/` 下
2. 确认 `node` 可用（`node -v`）
3. 按 `SKILL.md` 生成产物 → 需要离线就再跑一次 `build_offline.py`
4. 跑 `verify.py` 验收

**不需要** npm install、不需要构建工具、不需要 Python 虚拟环境（除 Pillow 可选）。
