# 踩坑记录 · 12 条（症状 → 根因 → 修法）

> 全部是本项目真实翻车过的。**出现对应症状时先来这里对，不要自己重新推一遍。**

---

## P-01 · 剖视看不出内部，切开的还是外壳

**症状**：点剖视后外壳还在，只切掉了背面那半边，正面照样挡着。

**根因**：three.js 的裁剪规则是「**法线·点 + constant < 0 的那一侧被移除**」。要切掉 x > c 的近相机侧，法线必须指 **−X**。写成 `+X` 就变成切远侧，近侧外壳完整保留。

**修法**：每帧按相机相对位置定符号。
```js
if (state.cut) {
  const sgn = camera.position.x >= controls.target.x ? -1 : 1;
  CLIP.normal.set(sgn, 0, 0);
  CLIP.constant = 0.02;
}
```
> 别写死符号——绕到另一侧再剖视就切反了。

---

## P-02 · 剖视后切面外留下悬空小黑点

**症状**：剖面外面漂着一圈黑色小点/小柱，明显不该在那里。

**根因**：`boltRing()` 生成的紧固件材质没有登记进 `CLIP_MATS`，剖视时没被裁掉，而它依附的壳体已经被裁掉了。

**修法**：凡是"贴在壳体表面上、并且应该随壳体一起消失"的材质，创建时第四个参数传 `true`（或手动 `CLIP_MATS.push(m)`）。本项目里 `boltRing` 用的 `boltMat` 就是 `matSteel(0x555F6B, 0.88, 0.44, true)`。

---

## P-03 · 法兰圆盘立成了薄片，侧看像一排楔形尖刺

**症状**：核心机表面本该是一圈圈平贴的圆盘接头，实际渲染成从侧面斜插出来的一片片刀。

**根因**：`CylinderGeometry` 轴默认沿 **+Y**。要让它平贴圆柱面（盘面法线 = 径向 `(cos a, sin a, 0)`），必须绕 Z 转 `a − π/2`。写成 `rotation.set(π/2, 0, a)` 会把轴先转到 **+Z**——圆盘就立成了薄片。

```js
// ✅ 正确
d.rotation.set(0, 0, a - Math.PI / 2);
// ❌ 错误（盘面立成薄片）
d.rotation.set(Math.PI / 2, 0, a);
```

**验证方法**：推导一遍——`Rz(φ)` 把 `(0,1,0)` 映射到 `(−sin φ, cos φ, 0)`；取 `φ = a − π/2` 得 `(−sin(a−π/2), cos(a−π/2), 0) = (cos a, sin a, 0)`，正是径向。✅

---

## P-04 · 卡箍像插在管子上的一片刀

**症状**：S 型引气管上的环形卡箍，侧看是竖着的一片片刀，不是套住管身的环。

**根因**：`TorusGeometry` 默认**就躺在 XY 平面**（法线 +Z）。管子大致沿 Z 走，正好该保持默认姿态。却写了 `rotation.set(0, π/2, a)` 把环立了起来。

**修法**：**不要旋转**。只设 `position`。
```js
const t = new THREE.Mesh(new THREE.TorusGeometry(0.146, 0.028, 6, 16), clampMat);
t.position.set(Math.cos(a) * r, Math.sin(a) * r, z);
// 不加任何 rotation
```

---

## P-05 · 盒子贴曲面时朝向错了，侧看是刀尖

**症状**：箍带端头搭接块、纵向加强条、检修口盖、凸耳——这些"贴在机匣面上的盒子"，旋转后朝向不对。

**根因**：两个独立错误叠加：
1. `box()` 的 `rotation.z` 参数被写成了 `π/2 − a`，正确就是 **`a`**。
2. 参数顺序误解：`box(w, h, d, ...)` 里 `w` 是**径向厚度**、`h` 是**切向宽度**、`d` 是**轴向长度**。写成"长 × 细 × 薄"就变成从罩体侧面斜插出来的刀。

**修法**：
```js
// 纵向加强条：径向 0.024（薄）· 切向 0.078 · 轴向 1.66（长）
box(0.024, 0.078, 1.66, stripMat, Math.cos(a)*r, Math.sin(a)*r, 4.34, 0, 0, a);
// 检修口盖：径向 0.016（薄）· 切向 0.34（宽）· 轴向 0.46（高）→ "宽 × 高 × 薄" ✅
box(0.016, 0.34, 0.46, doorMat, Math.cos(ang)*r, Math.sin(ang)*r, z, 0, 0, ang);
// 凸耳：切向必须够宽（0.13），否则轴向 0.34 的薄片侧看像刀尖
box(0.058, 0.130, 0.34, hubFrame, ..., 0, 0, a);
```

**自检口诀**：贴曲面的盒子，**第一维（径向）永远最小**，第二维（切向）要够宽。

---

## P-06 · 紧固件是朝前的一圈小柱，不是沿径向朝外

**症状**：机匣法兰上那圈螺栓，从侧面看是错位的黑点，不像螺栓头。

**根因**：`boltRing` 里用 `rotateX(π/2)` 想调整朝向，结果把圆柱轴转到了 **+Z**（朝前），一圈柱子冲着观察者。

**修法**：绕 Z 转 `a − π/2`，且先把几何沿自身轴抬半个高度，再从原点平移到半径处：
```js
const g0 = new THREE.CylinderGeometry(sz, sz, sz * 1.05, 6);
g0.translate(0, sz * 0.52, 0);      // 先抬，让底面贴住曲面
g0.rotateZ(a - Math.PI / 2);        // 轴 → 径向
g0.translate(Math.cos(a) * r, Math.sin(a) * r, z);  // 再就位
```
**顺序不可换**：先平移后旋转会把半径也一起转掉。

---

## P-07 · 锥面纵向安装边露出三角锯齿

**症状**：核心机罩是锥面（半径 2.42 → 1.80），沿它铺的纵向安装边出现一段段错位的三角缺口。

**根因**：用「一串盒子沿轴向拼」实现。每段盒子是直的，锥面是斜的，段与段之间必然错位 → 露三角。

**修法**：改用 `surfStrip()`，按型线**连续放样**，相邻段共用同圈顶点、外法线连续：
```js
railMat = matSteel(0x8E97A3, 0.85, 0.42, true);
[0.30, Math.PI - 0.30].forEach(a => {
  g.add(surfStrip(CORE_OUT, a, 2.80, -4.60, 0.013, 0.030, railMat, 56));
});
```
同理，**一整根定半径直条**在锥面上会两端悬空，也不能用。

---

## P-08 · 导流叶片叶尖悬空朝前戳出（一排三角尖刺）

**症状**：风扇机匣后端伸出一排三角形尖刺。

**根因**：OGV 放在 `z = 3.02`，但 `FANCASE` 型线只到 `z = 3.34`——3.02 已经在机匣之外。叶尖悬在空气里，朝前戳出。

**修法**：移进型线范围内，且叶尖半径**用 `sampleR` 算，不写死**：
```js
const OGV_Z = 3.66;                                          // 移进来
r1: sampleR(FANCASE_IN, OGV_Z) - 0.020                       // 自动跟随型线
```

**通用教训**：任何"端点贴在某个壳体上"的部件，端点位置都要先查壳体型线的 z 范围，再用 `sampleR` 求半径。硬编码数字在型线调整后必然出错。

---

## P-09 · 碳纤维机匣变成纯深灰，看不出编织纹

**症状**：风扇机匣是死板的深灰，没有编织质感。

**根因**：只用 `MeshStandardMaterial({color: 0x23282E})`，没上贴图。

**修法**：`carbonTexture()` + `map`，并且 `metalness` 压到 0.30、`roughness` 提到 0.56——高金属度会把贴图吃掉。
```js
const m = matStd(C.carbon2, 0.30, 0.56, { map: TEX.carbon, side: THREE.DoubleSide });
```

**同类问题**：S 型引气管给高 `metalness`（0.9）+ 贴图，在浅色环境里会反射成深灰近黑——实物是明亮哑光不锈钢。正确是 `metalness: 0.55, roughness: 0.30`，**不给贴图**。

---

## P-10 · 分解后部件被左右面板压住

**症状**：点分解，左下角的部件跑到左侧清单面板底下，右下角的跑到右侧详情面板底下。

**根因**：取景按**整窗** `camera.aspect` 算距离，完全没扣左栏 215 px / 右栏 330 px / 顶栏 108 px / 底栏 120 px。这些是盖在画布上的不透明面板，部件"在画布内"但"在视野外"。

**修法**：见 `spec-scene.md` 第九节完整实现。要点四条：
1. FOV 按**像素比例**缩到可用区（`vEff = vFov * usableH/H`），**改 aspect 不等效**
2. 包围盒 **8 个角**在相机系（right/up/camDir）投影
3. **注视点平移到可用区中心**，不是包围盒中心
4. **二分**求最小距离，`PAD = 0.92` 内缩留呼吸边距

**踩过的两个弯路**：
- 改 `camera.aspect` 为可用区宽高比 → 不等效，画面只是水平 FOV 变了，不会往一边挪
- 迭代式求解 `d` → **发散**。因为 `ox = dxPx·k·d` 与 `d` 成正比，`d` 越大偏移越大，正反馈。必须二分。

---

## P-11 · `maxDistance` 太小，分解后模型被切边

**症状**：分解态明明算好了取景距离，部件还是被切出画面。

**根因**：`controls.maxDistance = 96`。实测分解后包围球半径 **15.36**，窄窗口（1180px 附近）需要 ~130 的距离才装得下，被 96 硬截断。

**修法**：`maxDistance = 170`，同时相机 `far` 从 220 提到 **400**（否则远平面会切掉）。

---

## P-12 · 截图看不到改动生效（截到补间第一帧）

**症状**：改了代码跑无头截图，图里还是旧视角/旧状态，以为改动没生效。

**根因**：`--virtual-time-budget` 对 `requestAnimationFrame` 的推进**不可靠**。相机补间需要 ~67 帧才走完，截图往往停在第一帧。

**修法**：成品内置 `#instant` 开关，跳过补间直接落位：
```js
if (location.hash.toLowerCase().includes('instant')) {
  camera.position.copy(toP);
  controls.target.copy(newTgt);
  controls.update();
  camTween = null;
} else {
  tweenCam(toP, newTgt);
}
```
截图命令固定带 `#exp&instant`。

**同类坑**：`--dump-dom` 要把 console 抓出来必须加 `--enable-logging=stderr --v=1`，否则 `console.log` 全丢。

---

## 附 · 三个容易误判的"假缺陷"

### ① 装机内壁的小圆点是破面？
**不是**。那是 `perfTexture()` 声衬穿孔贴图（16×16 圆孔，`repeat(10,3)`），**有意设计**。

### ② `Identifier 'tgt' has already been declared`？
`explodeView()` 里先写了 `const sphere = ...; const tgt = sphere.center.clone();`，后面又写 `const tgt = center.clone();`。删掉前一处即可。`node --check` 抓得到这类问题。

### ③ 同名函数被定义两次造成 shadow？
Edit 修改 `fits()` 时容易留下旧版（无 PAD）和新版（有 PAD）两份，后者不生效。用 `grep -n "const fits"` 确认只有一处。

---

## 交互级缺陷（截图发现不了，必须点一遍）

### `ReferenceError: NAC_PARTS is not defined`
**症状**：首屏完全正常，点任意分类 chip 后控制台报错，筛选失效。

**根因**：`setFilter()` 里写了 `NAC_PARTS`，但实际定义的常量是 `NAC_HIDDEN`。首次运行不触发，鼠标一点就炸。

**修法**：统一用 `NAC_HIDDEN`。
```js
const list = PARTS.filter(p => (id === 'all' || p.cat === id)
  && !(state.bare && NAC_HIDDEN.indexOf(p.id) >= 0));
```

**教训**：只截首屏图会漏掉整类交互缺陷。**验收必须点一遍八项工具条 + 六个分类 chip + 至少三个部件行。**
