# 拉取 three.js r160 依赖到 assets/vendor
# 用法（在技能根目录执行）：
#   powershell -ExecutionPolicy Bypass -File scripts/fetch_vendor.ps1

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

$root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$vendor = Join-Path $root 'assets\vendor'
$base = 'https://cdn.jsdelivr.net/npm/three@0.160.0'

$map = [ordered]@{
  'three.module.js'                          = '/build/three.module.js'
  'addons\controls\OrbitControls.js'         = '/examples/jsm/controls/OrbitControls.js'
  'addons\environments\RoomEnvironment.js'   = '/examples/jsm/environments/RoomEnvironment.js'
  'addons\utils\BufferGeometryUtils.js'      = '/examples/jsm/utils/BufferGeometryUtils.js'
}

Write-Host "目标目录: $vendor"
foreach ($k in $map.Keys) {
  $dst = Join-Path $vendor $k
  $dir = Split-Path -Parent $dst
  if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
  if (Test-Path $dst) {
    Write-Host ("跳过（已存在）: {0}" -f $k)
    continue
  }
  try {
    Invoke-WebRequest -Uri ($base + $map[$k]) -OutFile $dst -TimeoutSec 90 -UseBasicParsing
    $len = (Get-Item $dst).Length
    Write-Host ("下载完成: {0}  {1:N0} bytes" -f $k, $len)
  } catch {
    Write-Host ("失败: {0}  {1}" -f $k, $_.Exception.Message) -ForegroundColor Red
  }
}

$total = (Get-ChildItem -Path $vendor -Recurse -File | Measure-Object -Property Length -Sum).Sum
Write-Host ("合计: {0:N2} MB" -f ($total / 1MB))
Write-Host '校验：three.module.js 应约 1,272,972 bytes（r160）'
