#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
LEAP-1B 发动机探索器 · 验证脚本

用法:
    python scripts/verify.py <产物.html> [--width 1600] [--height 900] [--out DIR]

做四件事（缺一不算通过）:
  1. 语法检查  —— 抽出 <script type="module"> 交给 node --check
  2. 真实渲染  —— 无头 Chrome 截四态（默认 / #cut / #installed / #exp&instant）
  3. 控制台扫描 —— --dump-dom + --enable-logging=stderr 抓 Uncaught / 报错
  4. 取景量测  —— 分解态非背景像素 bbox 是否落在可用区内（不压左右面板）

退出码: 0 全过 / 1 有失败项
"""

import argparse
import glob
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time

# ---------- 可用区（需与 CSS 断点 & explodeView() 保持一致） ----------
PANEL_LEFT = 255      # 左栏 215 + 40 安全边距
PANEL_RIGHT = 350     # 右栏 330 + 20
PANEL_TOP = 108
PANEL_BOTTOM = 120
WIDE_BREAK = 1180     # 低于此宽度面板隐藏

CHROME_CANDIDATES = [
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
    "/usr/bin/google-chrome",
    "/usr/bin/chromium",
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
]

OK, FAIL, WARN = "[PASS]", "[FAIL]", "[WARN]"
results = []


def log(tag, msg):
    print("%s %s" % (tag, msg))
    results.append((tag, msg))


def find_chrome():
    env = os.environ.get("CHROME_PATH")
    if env and os.path.isfile(env):
        return env
    for p in CHROME_CANDIDATES:
        if os.path.isfile(p):
            return p
    which = shutil.which("chrome") or shutil.which("google-chrome") or shutil.which("chromium")
    return which


# ---------- 1. 语法检查 ----------
def check_syntax(path):
    try:
        raw = open(path, "r", encoding="utf-8", errors="replace").read()
    except Exception as e:
        log(FAIL, "读取文件失败: %s" % e)
        return None

    m = re.search(r'<script type="module">(.*?)</script>', raw, re.S)
    if not m:
        log(FAIL, "未找到 <script type=\"module\">")
        return raw
    js = m.group(1)

    node = shutil.which("node")
    if not node:
        log(WARN, "未找到 node，跳过语法检查")
    else:
        fd, tmp = tempfile.mkstemp(suffix=".mjs")
        os.close(fd)
        open(tmp, "w", encoding="utf-8").write(js)
        try:
            r = subprocess.run([node, "--check", tmp], capture_output=True, text=True)
            if r.returncode == 0:
                log(OK, "语法检查通过 (node --check, %d 行模块脚本)" % len(js.splitlines()))
            else:
                err = (r.stderr or r.stdout).strip().splitlines()
                log(FAIL, "语法错误: %s" % " | ".join(err[:4]))
        finally:
            os.unlink(tmp)

    # 静态可疑项
    for name in ["NAC_PARTS", "NAC_HIDEN"]:
        if re.search(r'\b' + name + r'\b', js):
            log(FAIL, "发现未定义常量引用 %s（应为 NAC_HIDDEN）" % name)

    if js.count("const fits") > 1 or js.count("function fits") > 1:
        log(FAIL, "fits() 被重复定义，后者不生效")

    if "localClippingEnabled" not in js:
        log(FAIL, "缺少 renderer.localClippingEnabled，剖视不会生效")

    if "RoomEnvironment" not in js:
        log(WARN, "未使用 RoomEnvironment，金属材质会发黑")

    return raw


# ---------- 2/3. 截图 + 控制台 ----------
def _is_real_error(line):
    """判定一行日志是否真的是运行时异常。

    踩过的坑：离线版把 three.js 源码内联进页面，源码里本身含
    `TypeError` / `ReferenceError` 等字样（它自己的错误处理代码），
    --dump-dom 会把整段脚本回显出来，于是被判成"控制台异常"——纯假阳性。
    真正的异常在 stderr 里一定带 "Uncaught"、"CONSOLE" 或浏览器错误前缀。
    """
    low = line.lower()
    if re.search(r"updater|gpu_|dbus|fontconfig|update_service_dialer", low):
        return False
    # DOM dump 回显的源码行：超长、含大量转义、或以 const/let/function 开头
    if len(line) > 600:
        return False
    if re.match(r"\s*(const|let|var|function|class|\}|\{)\s", line):
        return False
    # 真正的运行时错误标志
    if "uncaught" in low:
        return True
    if re.search(r":error:console", low) and re.search(r"(error|exception)", low):
        return True
    if re.search(r"^\S*\s*\(?\d+\)?\s*\[.*\]\s*(uncaught|error)", low):
        return True
    # 单独的 TypeError:/ReferenceError: 出现在 "Uncaught" 之外的上下文里，
    # 只有当它同时带 file:// 或 http 的栈信息时才算
    if re.search(r"(typeerror|referenceerror|syntaxerror)", low) and ("file://" in low or "http" in low):
        return True
    return False


def shoot(chrome, path, out_dir, w, h, name, hash_="", budget=7000, dump=False, retries=2):
    """截图一次。连续快速启动 Chrome 会偶发产出 0 字节 PNG，
    这里做重试 + 间隔，避免把环境抖动误报成产物缺陷。"""
    out_png = os.path.join(out_dir, name + ".png")
    url = "file:///" + path.replace("\\", "/")
    if hash_:
        url += hash_

    last_bad = []
    for attempt in range(retries + 1):
        cmd = [chrome, "--headless=new", "--disable-gpu", "--allow-file-access-from-files",
               "--hide-scrollbars", "--window-size=%d,%d" % (w, h),
               "--virtual-time-budget=%d" % budget,
               "--enable-logging=stderr",
               "--user-data-dir=" + tempfile.mkdtemp(prefix="cc_")]
        if dump:
            cmd.append("--dump-dom")
        else:
            cmd.append("--screenshot=" + out_png)
        cmd.append(url)

        try:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=150)
        except subprocess.TimeoutExpired:
            if attempt < retries:
                time.sleep(2.0)
                continue
            raise

        err = (r.stderr or "") + (r.stdout or "")
        bad = [ln.strip()[:220] for ln in err.splitlines() if _is_real_error(ln)]
        last_bad = bad

        if dump:
            return None, bad
        size = os.path.getsize(out_png) if os.path.isfile(out_png) else 0
        if size >= 20000 or attempt >= retries:
            return out_png, bad
        time.sleep(2.0)          # 空图大概率是环境抖动，等一下重试

    return out_png, last_bad


def console_scan(chrome, path, out_dir, w, h):
    _, bad = shoot(chrome, path, out_dir, w, h, "_console", "", 5000, dump=True)
    if bad:
        for b in bad[:5]:
            log(FAIL, "控制台异常: %s" % b)
    else:
        log(OK, "控制台无 Uncaught / ReferenceError / TypeError")


# ---------- 4. 取景量测 ----------
def bbox_of_content(png, w, h):
    """灰度 < 150 的非背景像素 bbox（不能用 200，地面阴影会撑满全宽）"""
    try:
        from PIL import Image
    except ImportError:
        return None
    im = Image.open(png).convert("L")
    px = im.load()
    W, H = im.size
    x0, y0, x1, y1 = W, H, -1, -1
    for y in range(0, H, 2):
        for x in range(0, W, 2):
            if px[x, y] < 150:
                if x < x0: x0 = x
                if x > x1: x1 = x
                if y < y0: y0 = y
                if y > y1: y1 = y
    if x1 < 0:
        return None
    return (x0, y0, x1, y1, W, H)


def check_framing(png, w, h):
    bb = bbox_of_content(png, w, h)
    if bb is None:
        log(WARN, "取景量测跳过（无 Pillow 或图为空）")
        return
    x0, y0, x1, y1, W, H = bb
    wide = W > WIDE_BREAK
    lo_x = PANEL_LEFT if wide else 0
    hi_x = W - PANEL_RIGHT if wide else W
    lo_y, hi_y = PANEL_TOP, H - PANEL_BOTTOM

    tol = 6
    bad = []
    if x0 < lo_x - tol: bad.append("左边越界 x0=%d < %d" % (x0, lo_x))
    if x1 > hi_x + tol: bad.append("右边越界 x1=%d > %d" % (x1, hi_x))
    if y0 < lo_y - tol: bad.append("上边越界 y0=%d < %d" % (y0, lo_y))
    if y1 > hi_y + tol: bad.append("下边越界 y1=%d > %d" % (y1, hi_y))

    if bad:
        log(FAIL, "分解取景越界: %s（实测 bbox=%s）" % ("; ".join(bad), bb[:4]))
    else:
        log(OK, "分解取景在可用区内 bbox=(%d,%d)-(%d,%d) 可用=(%d,%d)-(%d,%d)"
            % (x0, y0, x1, y1, lo_x, lo_y, hi_x, hi_y))


# ---------- main ----------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("html")
    ap.add_argument("--width", type=int, default=1600)
    ap.add_argument("--height", type=int, default=900)
    ap.add_argument("--out", default=None)
    args = ap.parse_args()

    path = os.path.abspath(args.html)
    if not os.path.isfile(path):
        print("找不到文件: %s" % path)
        return 1

    out_dir = args.out or os.path.join(os.path.dirname(path), "_verify")
    os.makedirs(out_dir, exist_ok=True)

    print("=" * 68)
    print("LEAP-1B 探索器 · 验证  %s" % os.path.basename(path))
    print("视口 %dx%d  输出 %s" % (args.width, args.height, out_dir))
    print("=" * 68)

    print("\n[1] 语法检查")
    check_syntax(path)

    chrome = find_chrome()
    if not chrome:
        log(WARN, "未找到 Chrome/Edge，跳过渲染与控制台检查")
    else:
        print("\n[2] 真实渲染截图")
        states = [("bare", ""), ("cut", "#cut"), ("installed", "#installed"), ("exp", "#exp&instant")]
        shots = {}
        for name, h in states:
            try:
                png, bad = shoot(chrome, path, out_dir, args.width, args.height, name, h)
                sz = os.path.getsize(png) if png and os.path.isfile(png) else 0
                if sz < 20000:
                    log(FAIL, "%s 截图异常（%d 字节，可能白屏）" % (name, sz))
                else:
                    log(OK, "%s 截图 %d 字节 → %s" % (name, sz, os.path.basename(png)))
                    shots[name] = png
                if bad:
                    for b in bad[:3]:
                        log(FAIL, "%s 运行时报错: %s" % (name, b))
            except subprocess.TimeoutExpired:
                log(FAIL, "%s 截图超时" % name)

        print("\n[3] 控制台扫描")
        try:
            console_scan(chrome, path, out_dir, args.width, args.height)
        except subprocess.TimeoutExpired:
            log(FAIL, "控制台扫描超时")

        if "exp" in shots:
            print("\n[4] 分解取景量测")
            # 关键：量测必须用 #noui 隐藏 HTML 面板。
            # 面板自带深色文字，不隐藏会把 bbox 撑满整窗，量出来的数据毫无意义。
            try:
                mp, _ = shoot(chrome, path, out_dir, args.width, args.height,
                              "exp_noui", "#exp&instant&noui", 8000)
                check_framing(mp, args.width, args.height)
            except subprocess.TimeoutExpired:
                log(FAIL, "取景量测截图超时")

    print("\n" + "=" * 68)
    nf = sum(1 for t, _ in results if t == FAIL)
    nw = sum(1 for t, _ in results if t == WARN)
    if nf == 0:
        print("结论: 通过（%d 项警告）" % nw)
        print("下一步: 人工比对 assets/reference/ 四张基准图，并点一遍八项工具条 + 六个分类 chip")
        return 0
    print("结论: 失败 %d 项（%d 项警告）" % (nf, nw))
    return 1


if __name__ == "__main__":
    sys.exit(main())
