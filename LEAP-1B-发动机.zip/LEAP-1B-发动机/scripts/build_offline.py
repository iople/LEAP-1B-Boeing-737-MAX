#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
LEAP-1B 探索器 · 离线单文件构建

把 CDN 版产物转成**完全离线、双击即开**的单文件 HTML：
将 three.js r160 与三个 addon 内联进页面，用 Blob URL 动态 import，
绕开 file:// 下 ES module 的 CORS 限制。

用法:
    python scripts/build_offline.py <源.html> [-o <输出.html>]

原理:
  file:// 下 import 本地 .js 会被 CORS 拦（"--allow-file-access-from-files" 也无效），
  但 blob: URL 的模块导入是允许的。所以把依赖源码内联成字符串，
  运行时 createObjectURL 造出 blob，再把 addon 里的裸导入 'three'
  重写成 three 的 blob 地址。
"""

import argparse
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SKILL = os.path.dirname(HERE)
VENDOR = os.path.join(SKILL, "assets", "vendor")

VENDOR_FILES = {
    "three": "three.module.js",
    "orbit": os.path.join("addons", "controls", "OrbitControls.js"),
    "room": os.path.join("addons", "environments", "RoomEnvironment.js"),
    "merge": os.path.join("addons", "utils", "BufferGeometryUtils.js"),
}

# 源文件里的四条静态 import，替换为动态 blob import
IMPORT_PATTERNS = [
    (r"^\s*import\s+\*\s+as\s+THREE\s+from\s+['\"]three['\"]\s*;?\s*$", "__THREE__"),
    (r"^\s*import\s*\{\s*OrbitControls\s*\}\s*from\s*['\"]three/addons/controls/OrbitControls\.js['\"]\s*;?\s*$", "__ORBIT__"),
    (r"^\s*import\s*\{\s*RoomEnvironment\s*\}\s*from\s*['\"]three/addons/environments/RoomEnvironment\.js['\"]\s*;?\s*$", "__ROOM__"),
    (r"^\s*import\s*\{\s*mergeGeometries\s*\}\s*from\s*['\"]three/addons/utils/BufferGeometryUtils\.js['\"]\s*;?\s*$", "__MERGE__"),
]

RUNTIME = """
/* ===== 离线依赖引导（由 build_offline.py 注入）=====
   file:// 下 import 本地 .js 会被 CORS 拦截，但 blob: URL 可以。
   因此依赖源码内联在下方 __V 里，运行时造 blob 再动态 import。 */
const __V = __VENDOR_DATA__;
const __mkMod = (src, subs) => {
  let s = src;
  if (subs) for (const k in subs) {
    s = s.split("'" + k + "'").join("'" + subs[k] + "'");
    s = s.split('"' + k + '"').join('"' + subs[k] + '"');
  }
  return URL.createObjectURL(new Blob([s], { type: 'text/javascript' }));
};
const __threeURL = __mkMod(__V.three);
const __depSubs = { 'three': __threeURL };
const __orbitURL = __mkMod(__V.orbit, __depSubs);
const __roomURL  = __mkMod(__V.room,  __depSubs);
const __mergeURL = __mkMod(__V.merge, __depSubs);

const THREE = await import(__threeURL);
const { OrbitControls }   = await import(__orbitURL);
const { RoomEnvironment } = await import(__roomURL);
const { mergeGeometries } = await import(__mergeURL);
/* ===== 依赖引导结束 ===== */
"""


def read_vendor():
    data = {}
    for key, rel in VENDOR_FILES.items():
        p = os.path.join(VENDOR, rel)
        if not os.path.isfile(p):
            raise SystemExit("缺少依赖文件: %s\n请先运行 scripts/fetch_vendor.ps1 或手动放置。" % p)
        with open(p, "r", encoding="utf-8") as f:
            data[key] = f.read()
    return data


def build(src_path, out_path):
    with open(src_path, "r", encoding="utf-8") as f:
        html = f.read()

    # 1) 移除 importmap（离线版不再需要）
    html, n_map = re.subn(
        r'<script\s+type=["\']importmap["\']>.*?</script>\s*', "", html, flags=re.S)
    if n_map == 0:
        print("  [warn] 没找到 importmap，可能已是离线版")

    # 2) 取出 module 脚本
    m = re.search(r'(<script type="module">)(.*?)(</script>)', html, re.S)
    if not m:
        raise SystemExit("找不到 <script type=\"module\">")
    head, body, tail = m.group(1), m.group(2), m.group(3)

    # 3) 替换四条静态 import
    hits = {}
    lines = body.split("\n")
    out_lines = []
    for line in lines:
        done = False
        for pat, tag in IMPORT_PATTERNS:
            if re.match(pat, line):
                hits[tag] = hits.get(tag, 0) + 1
                out_lines.append("/* %s replaced by offline bootstrap */" % tag)
                done = True
                break
        if not done:
            out_lines.append(line)
    body = "\n".join(out_lines)

    missing = [t for _, t in IMPORT_PATTERNS if t not in hits]
    if missing:
        raise SystemExit("以下 import 未匹配到，无法离线化: %s" % ", ".join(missing))

    # 4) 注入运行时（内联依赖源码）
    vendor = read_vendor()
    runtime = RUNTIME.replace("__VENDOR_DATA__", json.dumps(vendor))
    new_body = runtime + "\n" + body

    html = html.replace(head + m.group(2) + tail, head + new_body + tail, 1)

    # 5) 标题标注离线版
    html = re.sub(r"<title>(.*?)</title>",
                  lambda mm: "<title>%s · 离线版</title>" % mm.group(1), html, count=1)

    with open(out_path, "w", encoding="utf-8") as f:
        f.write(html)

    size = os.path.getsize(out_path)
    print("  依赖内联: three=%d KB orbit=%d KB room=%d KB merge=%d KB"
          % (len(vendor["three"]) // 1024, len(vendor["orbit"]) // 1024,
             len(vendor["room"]) // 1024, len(vendor["merge"]) // 1024))
    print("  输出: %s  (%.2f MB)" % (out_path, size / 1048576.0))
    return out_path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("src")
    ap.add_argument("-o", "--out", default=None)
    a = ap.parse_args()

    src = os.path.abspath(a.src)
    if not os.path.isfile(src):
        raise SystemExit("找不到源文件: %s" % src)
    out = a.out or os.path.splitext(src)[0] + "-离线版.html"

    print("离线打包: %s" % os.path.basename(src))
    build(src, out)
    print("完成。双击打开即可，无需联网。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
