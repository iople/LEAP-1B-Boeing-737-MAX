---
name: LEAP-1B-发动机
description: 按实拍视频逐项校正，用 three.js 程序化重建 CFM LEAP-1B 涡扇发动机（波音 737 MAX 动力装置）单文件三维探索器——26 个部件、裸机/短舱双模、剖视、分解自动取景、点击明细。当用户要求"做 LEAP-1B / 737 MAX 发动机三维模型 / 发动机剖视分解图 / 按实拍视频精修发动机模型"时使用本技能。内含原始实拍视频、关键帧、四态基准渲染图与逐项规格，可在全新环境从零复刻。
agent_created: true
---

# LEAP-1B 涡扇发动机 · 实物精修三维探索器

**目标成果**：一个单文件 HTML（约 1900 行 / 95 KB），运行时用 three.js 拼出 LEAP-1B，默认呈现「拆掉短舱、架在展示台架上的裸机」，可一键切到完整短舱、剖视、分解，左侧 26 部件清单与右侧详情卡联动。

**核心方法论（一句话）**：外形不靠想象，靠实拍视频逐帧核对——先把「实拍里到底是什么颜色/什么形状」写下来，再改代码。

---

## 一、先看素材，再看规格

按顺序读完，不要跳：

| 顺序 | 文件 | 作用 |
|---|---|---|
| 1 | `assets/leap-1b-reference.mp4` | 原始实拍视频，23.4 s / 1280×720 / 30 fps。**这是一切外形判断的唯一依据** |
| 2 | `assets/frames/f01…f13.jpg` | 已抽好的 13 张关键帧，每 2 s 一张。免抽帧直接看 |
| 3 | `assets/reference/v2-bare.png` | 基准成品：裸机默认态（复刻后必须长这样） |
| 4 | `assets/reference/v2-cut.png` | 基准成品：剖视态 |
| 5 | `assets/reference/v2-installed.png` | 基准成品：完整短舱态 |
| 6 | `assets/reference/v2-exp.png` | 基准成品：分解态 |
| 7 | `references/spec-parts.md` | 26 部件全表：编号/中英名/分类/规格/说明/参数/分解向量/标签锚点 |
| 8 | `references/spec-geometry.md` | 四条型线数值 + 全部几何工具函数源码 + 26 个构建块的逐块参数 |
| 9 | `references/spec-scene.md` | 场景、光照、材质色值、相机、UI/交互/主循环参数 |
| 10 | `references/video-analysis.md` | 视频逐帧观察结论 → 8 处外形校正的推导过程 |
| 11 | `references/pitfalls.md` | 12 条几何朝向与取景纠错史（**每条都会让成品翻车，务必先读**） |
| 12 | `references/validation.md` | 验证四件套与脚本用法 |
| 13 | `references/deployment.md` | 依赖清单、离线单文件构建、迁移到新环境的步骤 |
| 14 | `references/selftest.md` | 可复刻性自测记录：另一 agent 从零重建的结果与偏差 |

---

## 二、六条铁律

违反任意一条都要返工。

1. **单文件 + CDN**：一个 `.html`，three.js 走 importmap 固定 **r160**：
   ```html
   <script type="importmap">
   {"imports":{
     "three":"https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js",
     "three/addons/":"https://cdn.jsdelivr.net/npm/three@0.160.0/examples/jsm/"}}
   </script>
   ```
   只引 `OrbitControls`、`RoomEnvironment`、`mergeGeometries` 三个 addon。**不引模型/贴图/HDR/字体文件**——所有纹理用 `CanvasTexture` 现场画，环境光用 `PMREMGenerator + RoomEnvironment` 现场烘。

2. **坐标约定一次定死**：**+Z 指发动机前方**（进气口在 +Z，尾锥在 −Z），**Y 向上**，半径绕 Z 轴。1 单位 = 0.25 m。全篇不换轴。

3. **数据驱动**：26 个部件全部写在 `PARTS` 数组里（`id/cn/en/cat/spec/desc/params`），列表行、计数、分类筛选、标签、明细卡、拾取高亮**全部由数组渲染**，任何地方禁止写死一条行。

4. **一组一件 + 材质不共用**：每个部件一个 `THREE.Group`，几何用**绝对世界坐标**建好；`group.position` 只由「分解向量 × 分解进度」驱动，绝不把静态偏移写进去（会被每帧覆盖）。每个部件在自建块里 `new` 自己的材质实例——共用会让高亮/淡出/剖切互相串。

5. **可裁剪的材质必须登记**：凡应被剖视切开的材质，创建时 `track(m, true)` 推进 `CLIP_MATS`；`applyCut()` 只遍历这个数组。漏登记的部件剖视时不会消失，会横在切口上。

6. **只新增文件**：不覆盖用户已有产物，迭代另存新版本号。

---

## 三、工作流

### 步骤 0 · 看视频定外形（不许跳过）

用 `assets/frames/` 里的帧逐张看图说话，把观察写成一句话一条，落到 `references/video-analysis.md` 的格式里。**关键观察点**（这 8 条直接决定产品长相，v1 全部做错了）：

1. 风扇机匣外壳是**黑色碳纤维编织**，不是浅灰——斜向编织纹在光下可见
2. 机匣外箍着 **4 道亮银金属带**：前两道窄且靠得近，后两道明显更宽、间距更大；另有纵向加强条与紧固件点阵
3. 风扇叶片是**宽弦、大扭转、叶尖前掠**的 18 片，受光偏银灰，**钛合金前缘包边最亮**
4. 整流锥是**深灰近黑复材**，锥面只有**一道白色螺旋**——不是白锥
5. 核心机顶部有两根**并排的大直径亮银导管**（引气管），走向沿机身向后弯成 S
6. 核心机表面**管线密布**：细钢管、红/橙护套软管、成束 FADEC 线缆，还有一堆**凸出的附件块**（泵体/阀块/接线盒）
7. 尾段是**一深一浅的多道环形加强肋**，侧看像"一摞盘"
8. 实物是**拆掉短舱架在落地支架上**的裸机姿态 —— 这应该是默认态

> 第 6 条最容易被忽略：v1 只铺了细管，看起来像"光筒上缠了几根线"；实物之所以"密"，一大半来自凸出机体。必须补 `boxAt()` 块体。

### 步骤 1 · 建型线与工具函数

抄 `references/spec-geometry.md` 的四条型线（`NAC_OUT/NAC_IN/CORE_OUT/CORE_IN/FANCASE/FANCASE_IN`）与 12 个工具函数去，逐字照抄，**不要"优化"数值**——这些数字是从视频里拟合出来的，改一个半径就可能让箍带从短舱里戳出来。

工具函数全景（签名与实现见规格）：

```
latheGeo(pts, seg)                      回转体，pts=[[z,r],...]
shellGeo(outPts, inPts, seg)            双层壳体（外型线 + 内型线闭合放样）
sampleR(pts, z)                         在型线上按 z 线性插值取半径
sliceP(pts, z0, z1)                     截取型线的一段
tubeShell(z0,z1,r0,r1,t,seg)            薄壁筒（带厚度）
box(w,h,d,mat,x,y,z,rx,ry,rz)           盒子 + 就位 + 旋转
surfStrip(prof,ang,zA,zB,halfAng,thick,mat,nZ)  沿回转面铺连续窄带
pathPipe(pts,rad,mat,tub,seg)           给点列做 CatmullRom 管
wrapPipe(o)                             沿核心机表面绕行的管路
boltRing(z,r,n,sz,mat)                  一圈径向朝外的六角头
bladeGeo(o)                             叶片放样（径向+Y/轴向+Z/绕Z排布）
ringOf(geo,count,phase)                 把一片几何绕 Z 阵列并合并
stageRing(o)                            压气机/涡轮级叶片环（盒子+预旋）
```

### 步骤 2 · 按 26 块建模型

严格按 `spec-geometry.md` 的顺序与参数建 `01`→`26`。每块都用 `addPart(id, group, ex, anchor)` 注册：

- `ex` = 分解向量（外壳沿径向/轴向让开、转子沿轴抽出、附件向下、台架向下）
- `anchor` = 标签锚点（世界坐标，放在该部件最容易被指到的位置）

### 步骤 3 · 场景与材质

照 `spec-scene.md` 配：`ACESFilmicToneMapping`（exposure 1.02）、`PCFSoftShadowMap`、`RoomEnvironment`（sigma 0.028）、三向光（key 2.30 / fill 0.88 / rim 1.20）、地面栅格 + `ShadowMaterial` 接影。材质色值表在 `C` 常量对象里，照抄。

四种程序化贴图缺一不可：`carbonTexture()`（碳纤维编织）、`brushedTexture()`（拉丝金属，双份亮度）、`perfTexture()`（声衬穿孔 16×16）、`spiralTexture()`（整流锥白螺旋）。

### 步骤 4 · 交互

八项工具条：分解 / 合拢 / 重置视角 / 标注 / 旋转 / 剖视 / 短舱（裸机双向切换）/ 管线。左侧 6 个分类 chip + 26 行列表，右侧详情卡（未选中时显示整机概览）。`dimTargets()` 统一管理淡出与 hover(蓝 `0x1E6FD9`)/select(橙 `0xF26A1E`) 发光。

**裸机/短舱双模**：`NAC_HIDDEN = ['01','02','09','10','11','25']` 在裸机隐藏，`26` 展示台架在短舱隐藏。注意 `06 风扇机匣`、`07 箍带`、`08 导流叶片` **两种模式都显示**——它们是裸机主角，且半径已收到短舱内壁以内，装机时不会戳出来。

### 步骤 5 · 验证（不做完不算交付）

跑 `python scripts/verify.py <产物.html>`，四件套全过：

1. `node --check` 抽取模块脚本 → 语法零错
2. 无头 Chrome 截四态（默认 / `#cut` / `#installed` / `#exp&instant`）
3. `--dump-dom` + 日志扫描 → 无 `Uncaught`
4. 人眼比对 `assets/reference/` 四张基准图

**交互自测必查一条**：点分类 chip 换筛选。`setFilter()` 里如果引用错常量（例如把 `NAC_HIDDEN` 写成不存在的 `NAC_PARTS`），点击瞬间抛 `ReferenceError`，但首屏完全正常——只看截图发现不了。

### 步骤 6 · 交付

产物落在**当前会话工作目录根**（`pwd` 所示目录），不建子目录。文件名带版本号，不覆盖旧成果。

**需要离线运行时**（内网 / 演示机 / 断网），再跑一次转换：

```bash
python scripts/build_offline.py <产物.html>
```

产出 `<原名>-离线版.html`（约 1.5 MB，依赖已内联，双击即开）。详见 `references/deployment.md`。

---

## 四、调试开关（写进成品，方便复现与验收）

成品支持 URL hash 注入状态，这是复刻时对齐基准图的手段：

| hash | 效果 |
|---|---|
| `#cut` | 直接进剖视 |
| `#installed` | 直接进完整短舱 |
| `#exp` | 直接进分解态 |
| `#instant` | **跳过相机补间，瞬间落位**。无头截图必须加——`--virtual-time-budget` 对 rAF 推进不可靠，不加只能截到补间第一帧 |
| `#labels` | 开标注 |
| `#hide=12,24` | 隐藏指定部件 |
| `#noui` | **隐藏全部 HTML 面板与工具条，只留画布**。量测模型实际像素范围必须用——面板文字本身是深色，不隐藏会把 bbox 撑满整窗 |
| `#dbg` | 每个部件换唯一纯色 + `NoToneMapping`，用像素颜色反查归属 |

`#dbg` 色值编码：`R=40+64*(i%4)`、`G=40+64*(⌊i/4⌋%4)`、`B=40+128*⌊i/16⌋`，配合 `setStyle` 走 sRGB 往返 + `toneMapped:false`，出图颜色与设定值一致。

---

## 五、能力边界（如实告知用户）

- **不是 CAD**：无工程精度、无公差、无真实叶片型线，叶片是参数化放样的示意叶型
- **级数与叶片数**：10 级 HPC、2 级 HPT、5 级 LPT、18 片风扇按公开资料还原；压气机每级 30/34 片、涡轮 46/48 片是**模型取值的示意数**，不等于真实叶数（真实单级齿数远多于此）
- **需要联网（CDN 版）**：three.js 从 jsDelivr 加载，离线打开会白屏。要离线请用 `scripts/build_offline.py` 转单文件版——**不要**试图把 vendor 改成相对路径，`file://` 下 ES module 会被 CORS 拦死，加浏览器启动参数也绕不过（已实测）
- **不覆盖短舱内部**：反推叶栅只做了套筒外形与作动筒方块，内部叶栅栅格未建
- **v1 → v2 的差异只在外形**：v1（`LEAP-1B-发动机-探索器.html`，21 部件）结构骨架正确，但颜色与特征与实物差距大；v2 是拿视频逐帧校正后的版本，26 部件

---

## 六、出错先查这里

`references/pitfalls.md` 收录了 12 条真实翻车记录，症状 → 根因 → 修法。**出现"某个小零件方向不对/看图像刀片/看图像尖刺/部件跑到面板底下/剖视看不出内部"时，先去那里对症状**，八成已经写过了。

最高频的三条：

1. 圆柱/圆环贴曲面时旋转轴搞错 → 圆盘立成薄片、卡箍像插在管上的刀（见 P-03/P-04/P-05）
2. 部件放在型线范围之外 → 叶尖悬空外戳（见 P-08）
3. 分解取景按整窗算 FOV → 部件被左右面板压住（见 P-10/P-11）
